<?php

$conexion= new mysqli("localhost","root","","proyecto");






?>
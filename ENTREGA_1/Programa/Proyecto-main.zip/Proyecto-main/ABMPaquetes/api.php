<?php



header('content-type: application/json');

echo json_encode($a);
?>
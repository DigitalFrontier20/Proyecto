<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilo.css">
    <title>Agregar</title>
</head>
<body>
    

<form method="POST" action="registroAgregado.php"  id="formAgregar" >

<h2>Nuevo Registro</h2>


<input name="id" type="number"placeholder="Id" id="id">
<br>
<br>
<input name="direccion" placeholder="Direccion" id="direccion">
<br>
<br>

<br>
<br>
<input type="submit" value="Agregar">

</form>
</body>
</html>
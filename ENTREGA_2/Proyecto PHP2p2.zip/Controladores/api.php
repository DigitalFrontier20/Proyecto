<?php

 
require("../Modelos/paquetesModelo.php");


$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode( '/', $uri );
$codigo=[$uri];
$u = new  paquetesModelo();
$respuesta=$u->list($codigo,$direccion);// llama a este metodo porque id tiene un valor

header("Content-Type:application/json");
echo json_encode($respuesta);


?>
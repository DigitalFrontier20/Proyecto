<?php
//en el require incluye el modelo que tiene clase y metodo 
//   que se quiere llamar

require_once("../Modelos/usuarioModelo.php");

class usuarioControlador
{



    public $id;
    public $nombre;
    public $password;
    public $tipo;



    public function agregarUsuario($nombre, $password, $tipo, $id)
    {
        $usuarioAgregar = new usuarioModelo();
        $nuevoUsuario = $usuarioAgregar->AgregarUsuario($nombre, $password, $tipo, $id);
    }


    public function eliminarUsuario($id)
    {
        $usuarioEliminar = new usuarioModelo();
        $eliminarUsuario = $usuarioEliminar->BorrarUsuario($id);
    }

    public function modificarUsuario($nombre, $password, $tipo, $id)
    {
        $usuarioModificar = new usuarioModelo();
        $modificarUsuario = $usuarioModificar->ModificarUsuario($nombre, $password, $tipo, $id);
    }





    public function iniciarSesion($nombre, $password)
    {
        $usuario = new usuarioModelo();
        $usuarioEncontrado = $usuario->buscarUsuarioPorNombrePassword($nombre, $password);

        if ($usuarioEncontrado) {
            session_start();
            $_SESSION['usuario'] = $usuarioEncontrado;

            if ($usuarioEncontrado['tipo'] === 'camionero') {
                header('Location: ../View/camioneroVista.php');
            } elseif ($usuarioEncontrado['tipo'] === 'funcionario') {
                header('Location: ../View/funcionarioVista.php');
            } elseif ($usuarioEncontrado['tipo'] === 'administrador') {
                header('Location: ../View/adminVista.php');
            }
        }
    }

}



$controlador = new usuarioControlador();
$controladorModificar = new usuarioControlador();
$controladorAgregar = new usuarioControlador();
$controladorBorrar = new usuarioControlador();


if (isset($_GET['opcion'])) {
    $opcion = $_GET['opcion'];
    switch ($opcion) {
        case 'login':
            if (isset($_GET['nombre']) and isset($_GET['password'])) {
                $nombre = $_GET['nombre'];
                $password = $_GET['password'];
                if ($controlador->iniciarSesion($nombre, $password)) {
                    echo "Inicio Correcto";
                } else {
                    $mensajerror = "puto";
                }

            }



            break;
        case 'agregar':
            if (isset($_GET['nombre']) and isset($_GET['password']) and isset($_GET['tipo']) and isset($_GET['id'])) {
                $nombre = $_GET['nombre'];
                $password = $_GET['password'];
                $tipo = $_GET['tipo'];
                $id = $_GET['id'];


                $controladorAgregar->agregarUsuario($nombre, $password, $tipo, $id);
            }

            break;

        case 'borrar':

            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                $id = $_GET['id'];

                $controladorBorrar->eliminarUsuario($id);
            }
            break;
        case 'modificar':

            if (isset($_GET['nombre']) and isset($_GET['password']) and isset($_GET['tipo']) and isset($_GET['id'])) {
                $nombre = $_GET['nombre'];
                $password = $_GET['password'];
                $tipo = $_GET['tipo'];
                $id = $_GET['id'];
                $controladorModificar->modificarUsuario($nombre, $password, $tipo, $id);
            }
            break;

    }




}

//MOSTRAR DATOS EN PANTALLA //
if (isset($_GET['nombre']) && $_GET['password'] and isset($_GET['id']) != "") {

    $nombre = $_GET['nombre'];
    $password = $_GET['password'];
    $id = $_GET['id'];


    $url = "http://localhost/Proyecto%20PHP2/Controladores/apiUsuarios.php" . $id;


    $client = curl_init($url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    $r = json_decode($response, true);











    //incluyo la vista que muestra informacion correspondiente


}





require_once("../View/usuarioVista.php");


?>
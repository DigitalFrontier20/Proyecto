<?php

$conexion = new mysqli("localhost", "root", "", "proyecto");

$sentencia = "select * from persona";

$registro = $conexion->query($sentencia);
$respuesta = array();

foreach ($registro->fetch_all(MYSQLI_ASSOC) as $asoc) {

    $array = [
        "nombre" => $asoc['nombre'],
        "password" => $asoc['password'],
        "tipo" => $asoc['tipo'],
        "id" => $asoc['id']


    ];
    array_push($respuesta, $array);

}




echo json_encode($respuesta);










?>
<?php

$conexion= new mysqli("localhost","root","","proyecto");

$sentencia = "select * from lotes";

$registro = $conexion->query($sentencia);
$respuesta = array();

foreach ($registro->fetch_all(MYSQLI_ASSOC) as $asoc) {

    $array = [
        "codigo" => $asoc['codigo'],
        "direccion" => $asoc['direccion'],
        "estado" => $asoc ['estado']
    

    ];
    array_push($respuesta, $array);

}




echo json_encode($respuesta);


?>






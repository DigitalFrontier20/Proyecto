<?php
    

class usuarioControlador
{





}

if (isset($_POST['registrar'])) {
    $codigo = $_POST['codigo'];
    $direccion = $_POST['direccion'];
    $estado = $_POST['estado'];

    $lote = array();
    for ($i = 0; $i < count($codigo); $i++) {
        $lote[] = array(
            'codigo' => $codigo[$i],
            'direccion' => $direccion[$i],
            'estado' => $estado[$i]
        );
    }

    echo json_encode($lote);

    $url = 'http://localhost/Proyecto%20PHP2/Controladores/apiLotes.php';
    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($lote));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt(
        $ch,
        CURLOPT_HTTPHEADER,
        array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen(json_encode($lote))
        )
    );

    $result = curl_exec($ch);
    curl_close($ch);

    echo $result;
}






?>

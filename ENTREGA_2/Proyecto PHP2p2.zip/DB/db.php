<?php
class db {
    protected $conexion;

    public function __construct() {
        $this->conexion = new mysqli("localhost", "root", "", "proyecto");
        
        if ($this->conexion->connect_error) {
            die("Error de conexión: " . $this->conexion->connect_error);
        }
    }

    public function insert($query) {
        return $this->conexion->query($query);
    }

    public function getError() {
        return $this->conexion->error;
    }
}
?>
create database proyecto;
use proyecto;
CREATE TABLE almacen (
    id INT AUTO_INCREMENT,
    calle VARCHAR(50) NOT NULL,
    nroPuerta INT NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    ciudad VARCHAR(50) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE paquete (
    id INT AUTO_INCREMENT ,
    calle VARCHAR(50) NOT NULL,
    nroPuerta INT NOT NULL,
    departamento VARCHAR(50)NOT NULL,
    ciudad VARCHAR(50)NOT NULL,
    fechaIngreso datetime,
    PRIMARY KEY (id)
);

CREATE TABLE lote (
    id INT PRIMARY KEY AUTO_INCREMENT,
    idAlmacen INT,
    FOREIGN KEY(idAlmacen) REFERENCES almacen(id),
	direccion VARCHAR(50)
);

CREATE TABLE lotesPaquetes(
	idPaquete INT PRIMARY KEY,
	idLote INT NOT NULL,
	FOREIGN KEY (idPaquete) REFERENCES paquete(id),
	FOREIGN KEY (idLote) REFERENCES lote(id)
);

CREATE TABLE camionero (
    id INT AUTO_INCREMENT,
    ci INT,
    PRIMARY KEY (id)
);

CREATE TABLE camion (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricula VARCHAR(7) NOT NULL
);



CREATE TABLE chofer (
    id INT AUTO_INCREMENT,
    ci INT,
    PRIMARY KEY(id)
);

CREATE TABLE pickup (
    id INT AUTO_INCREMENT,
    matricula VARCHAR(7) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE camioneroCamion(
idCamion int,
idCamionero INT,
estado varchar(20),
primary key(idCamion,idCamionero),
    FOREIGN KEY (idCamionero) REFERENCES camionero(id),
     FOREIGN KEY (idCamion) REFERENCES camion(id)
);

CREATE TABLE choferPickup(
idPickup INT,
idChofer int,
estado varchar(20),
primary key(idPickup,idChofer),
    FOREIGN KEY (idChofer) REFERENCES chofer(id),
    FOREIGN KEY (idPickup) REFERENCES pickup(id)
);

CREATE TABLE EnvioCamion(
	idLote INT PRIMARY KEY,
	idCamion INT,
	idAlmacenDestino INT,
    estado varchar(50),
	fecha DATETIME,
	FOREIGN KEY(idLote) REFERENCES lote(id),
	FOREIGN KEY(idCamion) REFERENCES camion(id),
	FOREIGN KEY(idAlmacenDestino) REFERENCES almacen(id)
);

CREATE TABLE EnvioPickup (
    idPaquete INT primary key,
    idPickup INT,
    estado varchar(50),
    fecha datetime,
    FOREIGN KEY (idPaquete) REFERENCES paquete(id),
    FOREIGN KEY (idPickup) REFERENCES pickup(id)
);

insert into camionero(ci) values 
(5431441),(4143123),(1241331),(1241242);

insert into chofer(ci) values 
(4567413),(1263164),(5682592),(6492595);

insert into camion(matricula) values 
('SCT1234'),
('SCH4563'),
('SCF2335'),
('ASF3313');

insert into pickup(matricula) values 
('SCG2413'),
('SHF9843'),
('AOE1264'),
('AWS1323');

insert into choferPickup(idPickup,idChofer) values 
(1,1),
(2,2),
(3,3);

insert into camioneroCamion(idCamion,idCamionero) values 
(1,1),
(2,2),
(3,3);

insert into almacen(calle,nroPuerta,departamento,ciudad) values 
('Magallanes',2431,'Montevideo','Montevideo'),
('Comercio',2223,'Canelones','Canelones'),
('Av.Italia',2343,'Durazno','Sarandi del Yi');

insert into paquete(calle,nroPuerta,departamento,ciudad,fechaIngreso) values 
('Aconcangua',2303,'Montevideo','Montevideo',current_time()),
('Michigan',6643,'Canelones','Canelones',current_time()),
('Av.Rivera',2573,'Rocha','La Paloma',current_time());

insert into lote(idAlmacen) values 
(1),
(2),
(3);

insert into lotesPaquetes(idLote,idPaquete) values
(1,1),
(1,2),
(3,3);

insert into EnvioCamion(idLote,idCamion,idAlmacenDestino,estado,fecha) values
(1,1,2,'En proceso',current_time()),
(2,1,2,'Finalizado',current_time()),
(3,2,3,'En proceso',current_time());

insert into EnvioPickup(idPaquete,idPickup,estado,fecha) values
(1,1,'En proceso',current_time()),
(2,1,'Finalizado',current_time()),
(3,2,'En proceso',current_time());


/*Consulta para probar el Envio en Camion */
select  t.idLote,c.matricula,a.calle,a.nroPuerta,a.departamento,a.ciudad,t.fecha from EnvioCamion t join lote l on t.idLote=l.id join camion c on c.id=t.idCamion join almacen a on a.id=t.idAlmacenDestino;

/*Consulta para probar los Lotes,su ubicacion y sus Paquetes*/
select e.idLote,e.idPaquete,p.calle,l.idAlmacen,a.calle,a.nroPuerta,a.departamento,a.ciudad from lotesPaquetes e join paquete p on e.idPaquete=p.id join lote l on l.id=e.idLote join almacen a on l.idAlmacen=a.id;

/*Consulta para probar el Envio en Pickup*/
select e.idPaquete,p.calle,p.nroPuerta,p.departamento,p.ciudad,v.matricula,e.fecha from EnvioPickup e join paquete p on e.idPaquete=p.id join pickup v on e.idPickup=v.id





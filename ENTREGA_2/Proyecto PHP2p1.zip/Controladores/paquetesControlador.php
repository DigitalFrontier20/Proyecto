<?php

require_once("../Modelos/paquetesModelo.php");
class paqueteControlador
{
    private $codigoborrar;
    private $nombre;
    private $direccion;

    private $estado;

    public static function list($context)
    {
        require("../Modelos/paquetesModelo.php");
        $u = new paquetesModelo();
        $respuesta = $u->list();

        echo json_encode($respuesta);
        return;
    }






    public function paquete($codigo, $direccion, $estado)
    {
        $paquetes = new paquetesModelo();
        $codigoEncontrado = $paquetes->AgregarPaquete($codigo, $direccion, $estado);
    }




    public function borrarpaquete($codigo)
    {
        $borrar = new paquetesModelo();
        $codigoeliminar = $borrar->BorrarPaquete($codigo);
    }

 
    public function modificarpaquete($codigo, $direccion, $estado)
    {
        $modificar= new paquetesModelo();
        $codigomodificar = $modificar->ModificarPaquete($codigo, $direccion, $estado);
    }






}



$controladormodificar = new paqueteControlador();
$controladoreliminar = new paqueteControlador();
$controlador = new paqueteControlador();


if(isset($_GET['opcion'])){ 
 $opcion=$_GET['opcion'];
switch($opcion){
    case 'agregar':
        if (isset($_GET['codigo']) and isset($_GET['direccion']) and isset($_GET['estado'])) {
            $codigo = $_GET['codigo'];
            $direccion = $_GET['direccion'];
            $estado = $_GET['estado'];
        
            $controlador->paquete($codigo, $direccion, $estado);
        }

        break;

        case 'borrar':

            if ($_SERVER['REQUEST_METHOD'] === 'GET') {
                $codigo = $_GET['codigo'];
            
                $controladoreliminar->borrarpaquete($codigo);
            }
            break;
            case 'modificar':

                if (isset($_GET['codigo']) and isset($_GET['direccion']) and isset($_GET['estado'])) {
                    $codigo = $_GET['codigo'];
                    $direccion = $_GET['direccion'];
                    $estado = $_GET['estado'];
                
                    $controladormodificar->modificarpaquete($codigo, $direccion, $estado);
                }
                break;
    }
}









//MOSTRAR DATOS EN PANTALLA //
if (isset($_GET['codigo']) && $_GET['codigo'] and isset($_GET['direccion']) && $_GET['direccion'] and isset($_GET['estado']) && $_GET['estado'] != "") {

    $codigo = $_GET['codigo'];
    $direccion = $_GET['direccion'];
    $estado = $_GET['estado'];


    $url = "http://localhost/Proyecto%20PHP2/Controladores/api.php" . $codigo;


    $client = curl_init($url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    $r = json_decode($response, true);










    //incluyo la vista que muestra informacion correspondiente


}


require_once("../View/usuarioVista.php");




?>
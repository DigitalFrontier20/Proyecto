<?php




$data = json_decode(file_get_contents('php://input'), true);

if ($data !== null && is_array($data)) {
    foreach ($data as $lote) {
        if (isset($lote['codigo']) && isset($lote['direccion']) && isset($lote['estado'])) {
            $codigo = $lote['codigo'];
            $direccion = $lote['direccion'];
            $estado = $lote['estado'];

            echo "Lote recibido: Código=$codigo, Dirección=$direccion, Estado=$estado\n";
        } else {
            echo "Error: Uno o más lotes no tienen las claves requeridas (codigo, direccion, estado)\n";
        }
    }
} else {
    echo "Error al procesar el JSON o no se recibieron datos\n";
}


?>
<?php

$conexion = new mysqli("192.168.5.50", "mauro.pistoni", "55477331", "digitalfrontier");
$entregadoValue = "Entregado";
$sentencia = "SELECT * FROM paquete WHERE estado != '$entregadoValue'";

$registro = $conexion->query($sentencia);
$respuesta = array();

foreach ($registro->fetch_all(MYSQLI_ASSOC) as $asoc) {

    $array = [
        "id" => $asoc['id'],
        "ciudad" => $asoc['ciudad'],
        "calle" => $asoc['calle'],
        "nroPuerta" => $asoc['nroPuerta'],
        "idDepartamento" => $asoc['idDepartamento'],
        "fechaIngreso" => $asoc['fechaIngreso'],
        "estado" => $asoc['estado'],
        "idLote" => $asoc['idLote'],
        


    ];
    array_push($respuesta, $array);

}




echo json_encode($respuesta);


?>
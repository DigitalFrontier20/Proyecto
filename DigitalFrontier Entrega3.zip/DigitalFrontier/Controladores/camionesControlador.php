<?php

require_once("../Modelos/camionerosModelo.php");

class CamionesControlador
{

    public $ci;
    public $matricula;


    public function buscar($ci)
    {
        $matricula = new camionerosModelo();
        return $matricula->buscarMatricula($ci);
    }
    public function verLotesCamiones($matricula)
    {
        $camionbuscar = new camionerosModelo();
        return $camionbuscar->buscarLoteCamion($matricula);
    }
    public function iniciarviaje($matricula)
    {
        $cambiarestado = new camionerosModelo();
        return $cambiarestado->iniciarViaje($matricula);
    }
    public function finalizarViaje($matricula)
    {
        $cambiarestado = new camionerosModelo();
        return $cambiarestado->finalizarViaje( $matricula);
    }

    public function agregarTablaCamion($ci, $matricula)
    {
        $agregarmatricula = new camionerosModelo();
        return $agregarmatricula->updatearChofer($ci, $matricula);
    }
    public function agregarCamion($matricula)
    {
        $camion = new camionerosModelo();
        return $camion->AgregarCamion($matricula);
    }

}

$camionControlador = new CamionesControlador();
$chofer = new CamionesControlador();






$estadocontrolador = new CamionesControlador();
$estadofinalizar = new CamionesControlador();
if (isset($_GET["id"]) and isset($_GET["accion"])) {
    $matricula = $_GET['id'];
    $accion = $_GET['accion'];
    switch ($accion) {
        case "iniciar":
            $b = $estadocontrolador->iniciarviaje($matricula);
            break;


        // Puedes agregar más casos según sea necesario
        case "finalizar":
            $c = $estadocontrolador->finalizarViaje($matricula);
            break;
        default:
            // Manejar acciones desconocidas
            break;
        case 'verlotes':
            $d = $buscarlotematricula->verLotesCamiones($matricula);
         
            break;
    }
}
//MOSTRAR DATOS EN PANTALLA //
if (isset($_GET['ci']) && $_GET['ci'] and isset($_GET['nombre']) && $_GET['nombre']) {

    $ci = $_GET['ci'];
    $nombre = $_GET['nombre'];


    $url = "http://localhost/DigitalFrontier/Controladores/apiCamiones.php" . $codigo;


    $client = curl_init($url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    $r = json_decode($response, true);

}
if (isset($_GET['matricula']) && $_GET['matricula'] and isset($_GET['estado']) && $_GET['estado'] and isset($_GET['ciCamionero']) && $_GET['ciCamionero']) {

    $ciCamionero = $_GET['ciCamionero'];
    $matricula = $_GET['matricula'];


    $urldos = "http://localhost/DigitalFrontier/Controladores/apiCamiones.php" . $codigo;


    $client = curl_init($urldos);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    $r = json_decode($response, true);

}


$updateChofer = new camionesControlador();
if (isset($_POST['ci']) and isset($_POST['matricula'])) {
    $ci = $_POST["ci"];
    $matricula = $_POST["matricula"];
    $updateChofer->agregarTablaCamion($ci, $matricula);
}


if (isset($_POST['opcion'])) {
    $opcion = $_POST['opcion'];
    switch ($opcion) {
        case 'agregar':
            if (isset($_POST['matricula']) and isset($_POST['idRuta'])) {
                $matricula = $_POST['matricula'];
                $idRuta = $_POST['idRuta'];
                $controlador = new camionesControlador();

                $a = $controlador->agregarCamion($matricula, $idRuta);


            }


            break;



    }
}





?>
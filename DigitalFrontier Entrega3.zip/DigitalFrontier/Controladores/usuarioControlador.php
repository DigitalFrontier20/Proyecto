<?php
//en el require incluye el modelo que tiene clase y metodo 
//   que se quiere llamar

require_once("../Modelos/usuarioModelo.php");

class usuarioControlador
{



    public $ci;
    public $nombre;
    public $password;
    public $tipo;



    public function agregarUsuario($ci, $nombre, $password, $tipo)
    {
        $usuarioAgregar = new usuarioModelo();
        $nuevoUsuario = $usuarioAgregar->AgregarUsuario($ci, $nombre, $password, $tipo);
    }


    public function eliminarUsuario($ci)
    {
        $usuarioEliminar = new usuarioModelo();
        $eliminarUsuario = $usuarioEliminar->BorrarUsuario($ci);
    }

    public function modificarUsuario($ci, $nombre, $password, $tipo)
    {
        $usuarioModificar = new usuarioModelo();
        $modificarUsuario = $usuarioModificar->ModificarUsuario($ci, $nombre, $password, $tipo);
    }

}



$controlador = new usuarioControlador();
$controladorModificar = new usuarioControlador();
$controladorAgregar = new usuarioControlador();
$controladorBorrar = new usuarioControlador();
$modelo = new usuarioModelo();


if (isset($_POST['opcion'])) {
    $opcion = $_POST['opcion'];
    switch ($opcion) {
        case 'login':
            if (isset($_POST['ci']) and isset($_POST['password'])) {
                $ci = $_POST['ci'];
                $password = $_POST['password'];
                $modelo->iniciarSesion($ci, $password);

            }
            break;


        case 'agregar':
            if (isset($_POST['ci']) and isset($_POST['nombre']) and isset($_POST['password']) and isset($_POST['tipo'])) {
                $ci = $_POST['ci'];
                $nombre = $_POST['nombre'];
                $password = $_POST['password'];
                $tipo = $_POST['tipo'];


                $controladorAgregar->agregarUsuario($ci, $nombre, $password, $tipo);
            }

            break;

        case 'borrar':

            if (isset($_POST['ci'])) {
                $ci = $_POST['ci'];
                $controladorBorrar->eliminarUsuario($ci);
            }

            break;
        case 'modificar':

            if (isset($_POST['ci']) and isset($_POST['nombre']) and isset($_POST['password']) and isset($_POST['tipo'])) {
                $ci = $_POST['ci'];
                $nombre = $_POST['nombre'];
                $password = $_POST['password'];
                $tipo = $_POST['tipo'];
                $controladorModificar->modificarUsuario($ci, $nombre, $password, $tipo);
            }
            break;

    }




}






require_once("../View/usuarioVista.php");


?>
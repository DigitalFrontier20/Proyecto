<?php

if (isset($_GET['datos'])) {
    $datos = $_GET['datos'];
    $urldecode = urldecode($datos);
    $jsonimprimir = json_decode($urldecode, true);




    echo json_encode($jsonimprimir);
    $lotejsonmandar = json_encode($jsonimprimir);
    $loteurl=urlencode($lotejsonmandar);
    header("Location:http://localhost/Proyecto/Controladores/mostrarLotes.php?datos=$loteurl");

}

?>
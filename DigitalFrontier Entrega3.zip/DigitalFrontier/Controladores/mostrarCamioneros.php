<?php



$conexion = new mysqli("192.168.5.50", "mauro.pistoni", "55477331", "digitalfrontier");
$sentencia = "SELECT p.ci, p.nombre
FROM persona p
WHERE p.tipo = 'Camionero'
AND NOT EXISTS (
    SELECT 1
    FROM camion cc
    WHERE cc.ciCamionero = p.ci
)";

$registro = $conexion->query($sentencia);
$respuesta = array();

foreach ($registro->fetch_all(MYSQLI_ASSOC) as $asoc) {

    $array = [
        "ci" => $asoc['ci'],
        "nombre" => $asoc['nombre']


    ];
    array_push($respuesta, $array);

}




echo json_encode($respuesta);











?>
<?php



 
require("../Modelos/usuarioModelo.php");


$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode( '/', $uri );
$codigo=[$uri];
$u = new  usuarioModelo();
$respuesta=$u->list($ci);// llama a este metodo porque id tiene un valor

header("Content-Type:application/json");
echo json_encode($respuesta);







?>
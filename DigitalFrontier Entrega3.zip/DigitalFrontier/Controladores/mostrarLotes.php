<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../View/style.css">
    <title>Registros</title>
</head>

<body>

    <header class="header-volver">

        <a href="../View/crearLote.php">
            <img id="img-volver" src="../View/Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Yorugua Express</h1>
    </header>

    <br>
    <br>
    <br>
</body>

</html>


<?php


if (isset($_GET['datos'])) {
    $datos = $_GET['datos'];
    $urldecode = urldecode($datos);
    $jsonimprimir = json_decode($urldecode, true);
    if (isset($_POST['registrar'])) {
        $codigo = $_POST['codigo'];
        //$direccion = $_POST['direccion'];
        $estado = $_POST['estado'];
        //$almacen = $_POST['almacen'];
        $IdLote = $_POST['IdLote'];
        $matricula = $_POST['matricula'];
        $departamento = $_POST['departamento'];
        for ($i = 0; $i < count($jsonimprimir); $i++) {
            $jsonimprimir[] = array(
                'codigo' => $codigo[$i],
                //'direccion' => $direccion[$i],
                'estado' => $estado[$i],
                //'almacen' => $almacen[$i],
                'IdLote' => $almacen[$i],
                'matricula' => $matricula[$i],
                 'fecha' => $departamento[$i]

            );
        }

    }
}
echo '<div id="containerTable1">';
echo '<section id="containerTable7">';
echo '<table>';

echo '<tr codigo="headTablefuncionario">';
echo '<h1>Lotes</h1>';
echo '<th>Codigo</th>';
echo '<th>Departamento</th>';
echo '<th>Matricula Del Camion</th>';
echo '<th>IdLote</th>';



echo '<tr>';
foreach ($jsonimprimir as $elemento) {
    echo '<tr>';
    echo '<td>' . $elemento['codigo'] . '</td>';
    // echo '<td>' . $elemento['direccion'] . '</td>';
    //echo '<td>' . $elemento['estado'] . '</td>';
    //echo '<td>' . $elemento['IdLote'] . '</td>';
    echo '<td>' . $elemento['departamento'] . '</td>';
    echo '<td>' . $elemento['matricula'] . '</td>';
    echo '<tr>';

}


echo '</div>';
echo '</div>';
?>



<?php




?>
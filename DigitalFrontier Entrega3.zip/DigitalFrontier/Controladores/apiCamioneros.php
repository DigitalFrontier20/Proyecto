<?php

require("../Modelos/camionerosModelo.php");

$mostrar = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$mostrar = explode( '/', $mostrar );
$idCamionero=[$mostrar];
$u = new  camionerosModelo();
$respuesta=$u->list($idCamionero);

header("Content-Type:application/json");
echo json_encode($respuesta);


?>
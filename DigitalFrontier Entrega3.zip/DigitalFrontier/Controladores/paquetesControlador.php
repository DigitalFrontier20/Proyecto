<?php

require_once("../Modelos/paquetesModelo.php");
class paqueteControlador
{
    private $codigoborrar;
    private $nombre;
    private $direccion;

    private $estado;

    public static function list($context)
    {
        require("../Modelos/paquetesModelo.php");
        $u = new paquetesModelo();
        $respuesta = $u->list();

        echo json_encode($respuesta);
        return;
    }




    public function buscarPaquete($idPaquete)
    {
        $modificar = new paquetesModelo();
        $codigomodificar = $modificar->buscarPaquete($idPaquete);
    }





    public function paquete($calle, $nroPuerta, $ciudad, $departamento)
    {
        $paquetes = new paquetesModelo();
        return $paquetes->AgregarPaquete($calle, $nroPuerta, $ciudad, $departamento);
    }




    public function borrarpaquete($id)
    {
        $borrar = new paquetesModelo();
        $codigoeliminar = $borrar->BorrarPaquete($id);
    }


    public function modificarpaquete($codigo, $calle, $nropuerta,$departamento)
    {
        $modificar = new paquetesModelo();
        $codigomodificar = $modificar->ModificarPaquete($codigo, $calle, $nropuerta,$departamento);
    }






}



$controladormodificar = new paqueteControlador();
$controladoreliminar = new paqueteControlador();
$controlador = new paqueteControlador();


if (isset($_POST['opcion'])) {
    $opcion = $_POST['opcion'];
    switch ($opcion) {
        case 'agregar':
            if (isset($_POST['calle']) and isset($_POST['nroPuerta']) and isset($_POST['departamento']) and isset($_POST['ciudad'])) {
                $calle = $_POST['calle'];
                $nroPuerta = $_POST['nroPuerta'];
                $departamento = $_POST['departamento'];
                $ciudad = $_POST['ciudad'];
                $a = $controlador->paquete($ciudad, $calle, $nroPuerta, $departamento);


            }


            break;

        case 'borrar':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $id = $_POST['id'];

                $controladoreliminar->borrarpaquete($id);
            }
            break;
        case 'modificar':

            if (isset($_POST['id']) and isset($_POST['calle']) and isset($_POST['nropuerta']) and isset($_POST['departamento'])) {
                $codigo = $_POST['id'];
                $calle = $_POST['calle'];
                $nropuerta = $_POST['nropuerta'];
                $departamento = $_POST['departamento'];

                $controladormodificar->modificarpaquete($codigo, $calle, $nropuerta,$departamento);
            }
            break;

        case 'buscar':

            if (isset($_POST['id'])) {
                $codigo = $_POST['id'];
                header("Location: usuarioVista.php?codigo=$codigo");


                $controladormodificar->modificarpaquete($codigo);
            }
            break;
    }
}










// Verificar si se ha enviado el ID del paquete desde el formulario
if (isset($_POST['paqueteId'])) {
    $paqueteId = $_POST['paqueteId'];

    // Crear una instancia del controlador y mostrar el usuario
    $controlador = new paqueteControlador();
    $controlador->buscarPaquete($paqueteId);
}








?>
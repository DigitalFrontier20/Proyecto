<?php 
$conexion=mysqli_connect('localhost','root','','proyecto');
$idRuta=$_POST['idRuta'];

	$sql="SELECT matricula
		from camionrutas
		where idRuta='$idRuta'";
        

	$result=mysqli_query($conexion,$sql);

	$cadena="<label>SELECT Camion(Camion)</label> 
			<select id='lista2' name='lista2'>";

	while ($ver=mysqli_fetch_row($result)) {
		$cadena=$cadena.'<option value='.$ver[0].'>'.utf8_encode($ver[0]).'</option>';
	}
	$selectCamion = $cadena."</select>";

	echo  $cadena."</select>";
	
	

?>
<?php

$conexion= new mysqli("192.168.5.50", "mauro.pistoni", "55477331", "digitalfrontier");

$sentencia = "select * from lotes";

$registro = $conexion->query($sentencia);
$respuesta = array();

foreach ($registro->fetch_all(MYSQLI_ASSOC) as $asoc) {

    $array = [
        "codigo" => $asoc['codigo'],
        "direccion" => $asoc['direccion'],
        "estado" => $asoc ['estado'],
        "idLote" => $asoc ['idLote']

    

    ];
    array_push($respuesta, $array);

}




echo json_encode($respuesta);








?>
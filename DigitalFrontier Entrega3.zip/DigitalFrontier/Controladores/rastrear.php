<?php

require_once("../Modelos/rastrearModelo.php");

class rastrear
{


    public $codigouser;

    public function buscarPaqueteUsuario($codigouser)
    {
        $usuario = new rastrearModelo();
        return $usuario->buscarPaquete($codigouser);
    }


}
$buscarPaqueteUserr = new rastrear();
if (isset($_POST["codigouser"])) {
    $codigouser = $_POST["codigouser"];
    $encontrado = $buscarPaqueteUserr->buscarPaqueteUsuario($codigouser);



    $codigoPaquete = json_encode($encontrado);
    $paqueteUrl = urlencode($codigoPaquete);
    header("Location:http://localhost/DigitalFrontier/View/mostrarUsuarioVista.php?dato=$paqueteUrl");
    exit;
}









?>
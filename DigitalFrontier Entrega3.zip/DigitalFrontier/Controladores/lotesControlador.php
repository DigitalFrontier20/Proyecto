<?php

require_once("../Modelos/lotesModelo.php");
require_once("../Modelos/paquetesModelo.php");

class lotesControlador
{

    public $idLote;
    public $codigo;

    public $direccion;

    public $estado;

    public $camion;

    public function buscarLote($idDepartamento)
    {
        $buscarLote = new lotesModelo();
        return $buscarLote->buscarLote($idDepartamento);
    }

    public function buscarPaquete($idLote)
    {
        $buscarPaquete = new lotesModelo();
        $result = $buscarPaquete->buscarLote($idLote);
        //  var_dump($result); // Agrega esta línea para verificar el resultado
        return $result;
    }

    public function buscarLoteDepartamento($departamento)
    {
        $buscarLote = new lotesModelo();
        return $buscarLote->buscarLoteAlmacen($departamento);
    }


    public static function asignarCamionLote($arrayIds, $matricula)
    {

        $u = new lotesModelo();
        $respuesta = $u->asignarCamionLote($arrayIds, $matricula);


        return;
    }


    public static function list($context)
    {

        $u = new paquetesModelo();
        $respuesta = $u->list();

        echo json_encode($respuesta);
        return;
    }

    public function buscarPorRuta($idRuta)
    {
        $buscarDepartamento = new lotesModelo();
        return $buscarDepartamento->buscarPaquetesPorRuta($idRuta);
    }
    /*
        public function buscarPorDepartamento($departamento)
        {
            $buscarPaquete = new lotesModelo();
            return $buscarPaquete->buscarPaquete($departamento);
        }


    */


    public function agregarLote($lote)
    {
        $LoteAgregar = new lotesModelo();
        $nuevoLote = $LoteAgregar->AgregarLote($lote);
    }

    public function traerPaquetes($departamento)
    {
        $buscarpaquete = new lotesModelo();
        return $buscarpaquete->buscarPaquete($departamento);
    }
}

$controladorBuscarPaquete = new lotesControlador();
$controladorLotes = new lotesControlador();
$controladorAlmacen = new lotesControlador();
$controladorLotePaquete = new lotesControlador();
$controladorLoteCamion = new lotesControlador();


$controlador = new lotesControlador();
if (isset($_POST["idRuta"])) {
    $idRuta = $_POST['idRuta'];
    $c = $controlador->buscarPorRuta($idRuta);
    // var_dump($c);


    $lotercamion = json_encode($c);
    $mandarloteurl = urlencode($lotercamion);
    header("Location:http://localhost/DigitalFrontier/View/asignarCamion.php?mandar=$mandarloteurl");
}



$controladorPaquetes = new lotesControlador();
$controladorEnvios = new lotesControlador();


$controlador = new lotesControlador();
if (isset($_POST['registrar'])) {
    $id = $_POST['id'];
    $departamento = $_POST['departamento'];

    $lote = array();
    for ($i = 0; $i < count($id); $i++) {
        $lote[] = array(
            'id' => $id[$i],
            
            'departamento' => $departamento[$i],

        );

    }
    $a = $controlador->agregarLote($lote);

    //  $b = $controlador->agregarLotePaquete($lote);



}




//MOSTRAR DATOS EN PANTALLA//
if (isset($_GET['codigo']) && $_GET['codigo'] and isset($_GET['direccion']) && $_GET['direccion'] and isset($_GET['estado']) && $_GET['estado'] and isset($_GET['idLote']) && $_GET['idLote'] != "") {

    $codigo = $_GET['codigo'];
    $direccion = $_GET['direccion'];
    $estado = $_GET['estado'];
    $idLote = $_GET['idLote'];



    $url = "http://localhost/DigitalFrontier/Controladores/apiLotesDos.php" . $idlote;


    $client = curl_init($url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    $r = json_decode($response, true);

    //incluyo la vista que muestra informacion correspondiente

}


$mandarPaquetes = new lotesControlador();

if (isset($_POST["departamento"])) {
    $departamento = $_POST['departamento'];
    $h = $mandarPaquetes->traerPaquetes($departamento);
    // var_dump($h);

    $lotercamion = json_encode($h);
    $mandarloteurl = urlencode($lotercamion);
    header("Location:http://localhost/DigitalFrontier/View/crearLote.php?mandar=$mandarloteurl");
}


$mandarLote = new lotesControlador();
if (isset($_POST["idRuta"])) {
    $idRuta = $_POST['idRuta'];
    $c = $mandarLote->buscarPorRuta($idRuta);
    // var_dump($c);



    $lotercamion = json_encode($c);
    $mandarloteurl = urlencode($lotercamion);
    header("Location:http://localhost/DigitalFrontier/View/asignarCamion.php?mandar=$mandarloteurl");
}


$controlador = new lotesControlador();
if (isset($_POST["id"]) and isset($_POST["idRuta"])) {
    $idRuta = $_POST['idRuta'];
    $c = $controlador->buscarPorRuta($idRuta);
    var_dump($c);


    $lotercamion = json_encode($c);
    $mandarloteurl = urlencode($lotercamion);
    header("Location:http://localhost/DigitalFrontier/View/asignarCamion.php?mandar=$mandarloteurl");
}

$buscarlotedepartamento = new lotesControlador();
if (isset($_GET["idDepartamento"])) {
    $departamento = $_GET['idDepartamento'];
    $j = $buscarlotedepartamento->buscarLoteDepartamento($departamento);



$mandarjson = json_encode($j);
$mandarurl = urlencode($mandarjson);
header("Location:http://localhost/DigitalFrontier/View/mostrarLotesCamion.php?dato=$mandarurl");
}


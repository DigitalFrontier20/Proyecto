<?php

require_once("../Modelos/camionerosModelo.php");

class camionerosControlador
{

    public $id;
    public $nombreChofer;
    public $matricula;
    public function camionero($nombreChofer, $matricula, $id)
    {
        $insertarChofer = new camionerosModelo();
        $choferInsertar = $insertarChofer->insertarChofer($nombreChofer, $matricula, $id);
    }
    public function buscar($jsonString)
    {
        $matricula = new camionerosModelo();
        return $matricula->buscarMatricula($jsonString);
    }

    public function verLotesCamiones($matricula)
    {
        $camionbuscar = new camionerosModelo();
        return $camionbuscar->buscarLoteCamion($matricula);
    }

}



$insertarChoferr = new camionerosControlador();
if (isset($_GET['idCamionero']) && $_GET['idCamionero'] and isset($_GET['nombre']) && $_GET['nombre'] and isset($_GET['matricula']) && $_GET['matricula'] != "") {

    $idCamionero = $_GET['idCamionero'];
    $nombre = $_GET['nombre'];
    $matricula = $_GET['matricula'];
    $url = "http://localhost/DigitalFrontier/Controladores/apiCamioneros.php" . $idCamionero;


    $client = curl_init($url);
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($client);
    $r = json_decode($response, true);

    //incluyo la vista que muestra informacion correspondiente
}
$chofer = new camionerosControlador();

if (isset($_GET["mandarci"])) {
    $ci = $_GET['mandarci'];
    $urldecode = urldecode($ci);
    $jsondeco = json_decode($urldecode, true);

    // Convertir el array a string
    $jsonString = json_encode($jsondeco);

    // Imprimir o hacer lo que necesites con la cadena resultante
  //  echo $jsonString;

    $a = $chofer->buscar($jsonString);
    
    if ($a === null) {
        // Mostrar alerta si no se encontraron camiones
        echo "<script>alert('No se encontraron camiones para el camionero.'); window.location('../View/formulario.php');</script>";
    } else {
        // Redireccionar solo si hay resultados
        $mandarjson = json_encode($a);
        $mandarurl = urlencode($mandarjson);
        header("Location: http://localhost/DigitalFrontier/View/camioneroMostrar.php?mandar=$mandarurl");
        exit(); // Importante: detener la ejecución del script después de la redirección
    }
}



$buscarlotematricula = new camionerosControlador();

if (isset($_GET['matricula'])) {
    $matricula = $_GET['matricula'];
    // var_dump($matricula); // Imprime el valor de la matrícula
    $h = $buscarlotematricula->verLotesCamiones($matricula);
    //var_dump($h);    
    $jsonmandar = json_encode($h);
    $urldecode = urldecode($jsonmandar);

    header("Location:http://localhost/DigitalFrontier/View/mostrarLotecamionero.php?mandar=$urldecode");



}



?>
<?php

require_once("../Modelos/almacenesModelo.php");

class almacenControlador
{
    public $idAlmacen;

    

    /*
    public function agregarAlmacen($calle, $nroPuerta, $departamento, $ciudad)
    {
        $almacenAgregar = new almacenesModelo();
        $nuevoAlmacen = $almacenAgregar->AgregarAlmacen($calle, $nroPuerta, $departamento, $ciudad);
    }
    */

    public function buscaralmacen($departamento)
    {
        $almacenbuscar = new almacenesModelo();
        return $almacenbuscar->buscarAlmacen($departamento);
    }
}

$buscarAlmacen = new almacenControlador();

if (isset($_POST['departamento'])) {
    $departamento= $_POST['departamento'];
    $almacenta = $buscarAlmacen->buscaralmacen($departamento);

   

}

$almacenurl=json_encode($almacenta);
header("Location:http://localhost/DigitalFrontier/View/mostrarDatosAlmacen.php?dato=$almacenurl");


   
   




?>
<?php
require_once("../Modelos/departamentoModelo.php");

class departamentoControlador
{
    public function buscarRuta($idDepartamento)
    {
        $buscarRuta = new departamentoModelo();
        return $buscarRuta->buscar($idDepartamento);
    }
}
$buscarRuta = new departamentoControlador();
if (isset($_GET['idDepartamento'])) {
    $idDepartamento = $_GET['idDepartamento'];
    // echo $idDepartamento;
    $a = $buscarRuta->buscarRuta($idDepartamento);

    $mandarjson = json_encode($a);
    $mandarurl = urlencode($mandarjson);
    header("Location:http://localhost/DigitalFrontier/View/mostrarLotecamionero.php?dato=$mandarurl");
}
?>
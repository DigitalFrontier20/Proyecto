<?php
class db {
    protected $conexion;

    public function __construct() {
        $this->conexion = new mysqli("192.168.5.50", "mauro.pistoni", "55477331", "digitalfrontier");
        
        if ($this->conexion->connect_error) {
            die("Error de conexión: " . $this->conexion->connect_error);
        }
    }

    public function insert($query) {
        return $this->conexion->query($query);
    }

    public function getError() {
        return $this->conexion->error;
    }
}
?>
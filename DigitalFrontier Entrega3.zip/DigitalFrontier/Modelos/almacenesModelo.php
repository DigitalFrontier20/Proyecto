<?php

require_once("../DB/db.php");

class almacenesModelo extends DB
{
    public int $idAlmacen;
    public String $calle ;
    public String $nroPuerta;
    public String $departamento;
    public String $ciudad;
    

/*
    public function AgregarAlmacen($calle, $nroPuerta, $departamento, $ciudad)
    {
        $query = "SELECT COUNT(*) as count FROM almacen where departamento='$departamento'";
        $result = $this->conexion->query($query);   
        $row = $result->fetch_assoc();
        if ($row['count'] > 0) {
            echo '<script language="javascript">alert ("Almacen  ya registrado"); window.location="../View/almacen.php";  </script>';



        } else {
            $idAlmacen=$idAlmacen+1;
            echo '<script language="javascript">alert ("Almacen registrado");  window.location="../View/almacen.php"; </script>';
            $query = "INSERT INTO almacen (calle, nroPuerta, departamento, ciudad)  VALUES ('$calle','$nroPuerta','$departamento','$ciudad')";
            return $this->conexion->query($query);

        }
    }
    */
    
    public function buscarAlmacen($departamento)
    {
        $almacen = $this->conexion->real_escape_string($departamento);
        $consulta = "SELECT * FROM almacen WHERE idDepartamento='$departamento'";
        $filas = $resultado = $this->conexion->query($consulta);

        $almacen = array();
        foreach ($filas as $fila) {
            $almacen[] = $fila;
        }
        return $almacen;
    }

   

}
?>
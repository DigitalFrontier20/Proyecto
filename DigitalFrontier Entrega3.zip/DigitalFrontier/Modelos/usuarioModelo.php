<?php
require_once("../DB/db.php"); // tiene conexion a BaseDatos
class usuarioModelo extends DB
{

    public $ci;
    public $nombre;
    public $password;
    public $tipo;

    public function __construct()
    {
        parent::__construct();
    }

    public function list()
    {
        $consulta = $this->conexion->query("select * from persona");
        $filas = $consulta->fetch_all(MYSQLI_ASSOC);
        $personas = array();
        foreach ($filas as $fila) {
            $personas[] = $fila;
        }
        return $personas;
    }

    public function buscarUsuarioPorCiPassword($ci, $password)
    {
        $ci = $this->conexion->real_escape_string($ci);
        $password = $this->conexion->real_escape_string($password);

        $consulta = "SELECT * FROM persona WHERE ci='$ci' AND password='$password'";
        $resultado = $this->conexion->query($consulta);

        if ($resultado->num_rows === 1) {
            return $resultado->fetch_assoc();
        } else {
            return false;
        }
    }

    public function iniciarSesion($ci, $password)
    {
        $usuario = new usuarioModelo();
        $usuarioEncontrado = $usuario->buscarUsuarioPorCiPassword($ci, $password);

        if ($usuarioEncontrado) {
            session_start();
            $_SESSION['usuario'] = $usuarioEncontrado;

            if ($usuarioEncontrado['tipo'] === 'Camionero') {
                header('Location: ../View/camioneroVista.php');
                $mandarcidecamionero = json_encode(['ci' => $ci]);
                $mandarci = urlencode($mandarcidecamionero);
                header("Location:http://localhost/DigitalFrontier/Controladores/camionerosControlador.php?mandarci=$mandarci");
            } elseif ($usuarioEncontrado['tipo'] === 'Funcionario') {
                header('Location: ../View/funcionarioVista.php');
            } elseif ($usuarioEncontrado['tipo'] === 'Administrador') {
                header('Location: ../View/adminVista.php');
            }

        } else {
            echo '<script>';
            echo 'alert("Contraseña incorrecta. Por favor, inténtelo nuevamente.");';
            echo 'window.history.back();'; // Regresar a la página anterior
            echo '</script>';
        }

    }


    public function AgregarUsuario($ci, $nombre, $password, $tipo)
    {


        $query = "SELECT COUNT(*) as count FROM persona where ci='$ci'";
        $result = $this->conexion->query($query);
        $row = $result->fetch_assoc();
        if ($row['count'] > 0) {
            echo '<script language="javascript">alert ("CI  ya registrado"); window.location="../View/abmUsuarios.php";  </script>';



        } else {

            echo '<script language="javascript">alert ("CI registrado");  window.location="../View/abmUsuarios.php"; </script>';
            $query = "INSERT INTO persona (ci, nombre, password, tipo)  VALUES ('$ci','$nombre','$password','$tipo')";
            return $this->conexion->query($query);

        }
    }

    public function BorrarUsuario($ci)
    {
        echo '<script language="javascript">alert ("Se elimino correctamente");  window.location="../View/abmUsuarioS.php";   </script>';
        $query = "DELETE FROM persona WHERE ci='$ci'";
        return $this->conexion->query($query);
    }








    public function ModificarUsuario($ci, $nombre, $password, $tipo)
    {


        echo '<script language="javascript">alert ("Se Modifico correctamente");  window.location.href="../View/abmUsuarios.php";  </script>';
        $query = "UPDATE  persona  SET nombre='$nombre',  password='$password', tipo='$tipo' WHERE ci='$ci'";
        return $this->conexion->query($query);

    }




    public function cerrarConexion()
    {
        $this->conexion->close();
    }


}
?>
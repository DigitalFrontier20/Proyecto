<?php

require("../DB/db.php");
class camionerosModelo extends DB
{

    public function __construct()
    {
        parent::__construct();
    }

    public function list()
    {
        $insertar = $this->conexion->query("select * from camioneros;");
        $filas = $insertar->fetch_all(MYSQLI_ASSOC);
        $camioneros = array();
        foreach ($filas as $fila) {
            $camioneros[] = $fila;
        }
        return $camioneros;
    }
    public function AgregarCamion($matricula, $ciCamionero = null)
{
    $consulta = $this->conexion->prepare("INSERT INTO camion (matricula, ciCamionero) VALUES (?, ?)");
    $consulta->bind_param("ss", $matricula, $ciCamionero);

    // Ejecutar la consulta de inserción
    $resultadoInsercion = $consulta->execute();

    if ($resultadoInsercion) {
        header("Location: ../View/camioneroVistaAdmin.php");
        exit();
    } else {
        // Manejar el error de inserción, si es necesario
        echo "Error al insertar el camión: " . $consulta->error;
    }

    // Cerrar la consulta preparada
    $consulta->close();
}

    public function buscarMatricula($jsonString)
    {
        $camiones = array();

        // Decodificar el JSON a un array asociativo
        $jsonArray = json_decode($jsonString, true);

        // Obtener el valor de 'ci' del array (si existe)
        $ciCamionero = isset($jsonArray['ci']) ? $jsonArray['ci'] : '';

        // Aplicar trim al valor obtenido
        $ciCamionero = $this->conexion->real_escape_string(trim($ciCamionero));

        $consulta = "SELECT * FROM camion WHERE ciCamionero='$ciCamionero'";
        $resultado = $this->conexion->query($consulta);

        if ($resultado) {
            while ($camionFila = $resultado->fetch_array()) {
                $camiones[] = $camionFila;
            }

            if (!empty($camiones)) {
                return $camiones;
            } else {
                // echo "No se encontraron camiones para el camionero con CI: $ciCamionero";
                return null;
            }
        } else {
            // Manejo de errores si la consulta no fue exitosa
            echo "Error en la consulta: " . $this->conexion->error;
            return null;
        }
    }

    public function iniciarViaje($matricula)
    {
        $estado = "En Camino";

        // Actualizar el estado en la tabla camion
        $consulta = "UPDATE camion
        JOIN lote ON camion.matricula = lote.camion
        JOIN paquete ON lote.id= paquete.idLote
        SET camion.estado = '$estado',
            paquete.estado = '$estado'
        WHERE lote.id= '$matricula';";
        $resultado = $this->conexion->query($consulta);
        

        if ($resultado) {
            // Éxito: Mostrar una alerta y redirigir
            echo '<script>alert("Viaje iniciado correctamente"); window.location.href="../View/formulario.php";</script>';
        } else {
            // Error: Mostrar una alerta de error
            echo '<script>alert("Error al iniciar el viaje"); window.location.href="../View/formulario.php";</script>';
        }
    }


    public function finalizarViaje($matricula)
    {
        $estado = "Finalizado";

        // Actualizar el estado en la tabla camion
        $consulta = "UPDATE camion
        JOIN lote ON camion.matricula = lote.camion
        JOIN paquete ON lote.id= paquete.idLote
        SET camion.estado = '$estado',
            paquete.estado = '$estado'
        WHERE lote.id= '$matricula';";
        $resultado = $this->conexion->query($consulta);
        

        if ($resultado) {
            // Éxito: Mostrar una alerta y redirigir
            echo '<script>alert("Viaje finalizado correctamente"); window.location.href="../View/formulario.php";</script>';
        } else {
            // Error: Mostrar una alerta de error
            echo '<script>alert("Error al iniciar el viaje"); window.location.href="../View/formulario.php";</script>';
        }

    }

    /*

    public function insertarChofer($nombreChofer, $matricula, $id)
    {
        $tipo = "camionero";
        $query = "SELECT COUNT(*) as count FROM camioneros where idCamionero='$id'";
        $query2 = "SELECT COUNT(*) as count FROM persona where id='$id'";
        $result = $this->conexion->query($query);
        $result2 = $this->conexion->query($query2);

        $row = $result->fetch_assoc();
        $row2 = $result2->fetch_assoc();
        if ($row['count'] > 0 and $row['count'] > 0) {
            echo '<script language="javascript">alert ("ID  ya registrado"); window.location="../View/camioneroVista.php";  </script>';



        } else {
            echo '<script language="javascript">alert ("Chofer registrado");  window.location="../View/camioneroVista.php"; </script>';
            $query = "INSERT INTO camioneros (nombre, matricula, idCamionero)  VALUES ('$nombreChofer','$matricula','$id')";
            $query2 = "INSERT INTO persona (nombre,tipo, id)  VALUES ('$nombreChofer','$tipo','$id')";
            return $this->conexion->query($query) and $this->conexion->query($query2);


        }
    }


        public function traercicamionero()
        {
            $persona = array();
            $tipo = "Camionero";
            $consulta = "SELECT * FROM persona WHERE tipo='$tipo'";
            $resultado = $this->conexion->query($consulta);
            if ($resultado) {
                            while ($camionFila = $resultado->fetch_array()) {
                    $persona[] = $camionFila;
                }
                if (!empty($persona)) {
                    return $persona;
                }
            }

        }


    */





    public function updatearChofer($ci, $matricula)
    {
        echo '<script>alert("Se asigno Correctamente");</script>';
        $consulta = "UPDATE camion SET ciCamionero = '$ci' WHERE matricula = '$matricula'";
        $resultado = $this->conexion->query($consulta);

        if (!$resultado) {
            echo "Error al ejecutar la consulta: " . $this->conexion->error;
        }
    }

    

    public function buscarLoteCamion($matricula)
    {
        // Eliminar espacios en blanco alrededor de la matrícula
        $matricula = trim($matricula);

        $consulta = "SELECT * FROM lote WHERE camion=?";
        $stmt = $this->conexion->prepare($consulta);
        $stmt->bind_param("s", $matricula);
        $stmt->execute();
        $resultado = $stmt->get_result();

        // Verifica si hay errores de MySQL
        if (!$resultado) {
            echo "Error en la consulta: " . $this->conexion->error;
            return null;
        }

        $lotesCamiones = array();
        foreach ($resultado as $fila) {
            $lotesCamiones[] = $fila;
        }

        return $lotesCamiones;
    }


}

?>
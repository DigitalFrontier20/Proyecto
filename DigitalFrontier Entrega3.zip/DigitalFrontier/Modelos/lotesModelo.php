<?php

require_once("../DB/db.php"); // tiene conexion a BaseDatos

class lotesModelo extends DB
{
    public $codigo;
    public $direccion;

    public $estado;


    public $IdLote;


    public function __construct()
    {
        parent::__construct();
    }


    public function buscarPaquete($departamento)
    {
        // Verificar si $departamento es un array y tomar el primer valor
        if (is_array($departamento)) {
            // Tomar el primer valor del array
            $departamento = reset($departamento);

            // Verificar si el valor es una cadena antes de aplicar trim
            if (!is_string($departamento)) {
                // Manejar el caso donde no es una cadena
                return array();
            }
        }

        // Escapar y limpiar la cadena $departamento
        $departamento = $this->conexion->real_escape_string(trim($departamento));

        // Realizar la consulta
        $consulta = "SELECT * FROM paquete WHERE idDepartamento='$departamento' AND (idLote IS NULL OR idLote = '') AND estado <> 'Entregado'";
        $resultado = $this->conexion->query($consulta);

        // Verificar si la consulta fue exitosa
        if (!$resultado) {
            // Manejar el caso donde hay un error en la consulta
            echo "Error en la consulta: " . $this->conexion->error;
            return array();
        }

        // Obtener los resultados de la consulta
        $paquetes = array();
        while ($fila = $resultado->fetch_assoc()) {
            $paquetes[] = $fila;
        }

        // Cerrar la conexión y retornar los resultados
        $resultado->close();
        return $paquetes;
    }


    public function asignarCamionLote($arrayIds, $matricula)
    {
        foreach ($arrayIds as $id) {
            $query = $this->conexion->prepare("UPDATE lote SET camion=? WHERE id=?");
            $query->bind_param('si', $matricula, $id);

            // Verificar si la consulta fue exitosa
            if ($query->execute() && $query->affected_rows > 0) {
                // Llamada al método crearEnvio
                $this->crearEnvio($id, $matricula);
            } else {
                return false; // Hubo un error en la actualización
            }
        }

        return true;
    }

    public function buscarLoteAlmacen($departamento)
    {
        $departamento = $this->conexion->real_escape_string(trim($departamento));
        $consulta = "SELECT * FROM lote WHERE idDepartamento='$departamento'";
        $resultado = $this->conexion->query($consulta);

        $lote = array();

        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $lote[] = $fila;
            }
        } else {
            echo "<script>alert('No se encontraron registros para la matricula: $departamento');</script>";
        }

        return $lote;
    }



    public function buscarLoteCamion($matricula)
    {
        $matricula = $this->conexion->real_escape_string(trim($matricula));
        $consulta = "SELECT * FROM lote WHERE camion='$matricula'";
        $resultado = $this->conexion->query($consulta);

        $lote = array();

        if ($resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                $lote[] = $fila;
            }
        } else {
            echo "<script>alert('No se encontraron registros para la matricula: $matricula');</script>";
        }

        return $lote;
    }
    public function buscarPaquetesPorRuta($idRuta)
    {
        $query = "SELECT l.* 
        FROM lote l
        JOIN departamento d ON l.idDepartamento = d.id
        JOIN rutadepartamento rd ON d.id = rd.idDepartamento
        WHERE rd.idRuta = '$idRuta' AND (l.camion IS NULL OR l.camion = '')";
        $result = $this->conexion->query($query);

        if (!$result) {
            die("Error en la consulta: " . $this->conexion->error);
        }

        $paquetes = array();

        while ($fila = $result->fetch_assoc()) {
            $paquetes[] = $fila;
        }

        return $paquetes;
    }






    private $ultimoIdLote;

    // ... Resto del código
    public function AgregarLote($lote)
    {
        // Preparación de consulta para obtener la matrícula
        $matricula = null; 
        $consultaMatricula = "SELECT DISTINCT c.matricula
                              FROM camion c
                              JOIN camionrutas cr ON c.matricula = cr.matricula
                              JOIN rutadepartamento rd ON cr.idRuta = rd.idRuta
                              WHERE rd.idDepartamento = ?";
        $sentenciaMatricula = $this->conexion->prepare($consultaMatricula);
        $sentenciaMatricula->bind_param("i", $departamento); // Cambiado a parámetro
    
        // Preparación de consulta para verificar la existencia del lote
        $consultaExistencia = "SELECT id FROM lote WHERE camion = ? AND idDepartamento = ?";
        $sentenciaExistencia = $this->conexion->prepare($consultaExistencia);
        $sentenciaExistencia->bind_param("si", $matricula, $departamento);
    
        foreach ($lote as $dato) {
            $departamento = $dato['departamento'];
            $id = $dato['id'];
    
            // Obtener la matrícula
            $sentenciaMatricula->execute();
            $resultadoMatricula = $sentenciaMatricula->get_result();
    
            if ($resultadoMatricula->num_rows > 0) {
                $rowMatricula = $resultadoMatricula->fetch_assoc();
                $matricula = $rowMatricula['matricula'];
                if (array_key_exists('matricula', $rowMatricula)) {
                    
                    var_dump($matricula); // Agregado para depurar
                } else {
                    echo "La clave 'matricula' no existe en el array.<br>";
                    continue; // Saltar a la siguiente iteración si no existe la clave 'matricula'
                }
            } else {
                echo "No se encontró matrícula para el departamento: $departamento<br>";
                continue; // Saltar a la siguiente iteración si no se encuentra la matrícula
            }
          
    
            // Verificar si existe un lote con la misma matrícula y departamento
            $sentenciaExistencia->execute();
            $resultadoExistencia = $sentenciaExistencia->get_result();
    
            // Reiniciar el último ID de lote
            $ultimoIdLote = null;
    
            if ($resultadoExistencia->num_rows > 0) {
                // Lote ya existe, obtenemos el ID existente
                $rowExistencia = $resultadoExistencia->fetch_assoc();
                $ultimoIdLote = $rowExistencia['id'];
                $consultaActualizarPaquete = "UPDATE paquete SET idLote = ? WHERE id = ?";
                $queryActualizarPaquete = $this->conexion->prepare($consultaActualizarPaquete);
                $queryActualizarPaquete->bind_param('ii', $ultimoIdLote, $id);
                $queryActualizarPaquete->execute();
                echo "Lote existente con ID: $ultimoIdLote<br>";
            } else {
                // Lote no existe, procedemos con la inserción
                $consultaLote = "INSERT INTO lote (camion, idDepartamento) VALUES (?, ?)";
                $sentenciaLote = $this->conexion->prepare($consultaLote);
                $sentenciaLote->bind_param("si", $matricula, $departamento);
                $resultadoLote = $sentenciaLote->execute();
    
                if (!$resultadoLote) {
                    echo "Error al insertar nuevo lote: " . $sentenciaLote->error . "<br>";
                    return false; // Error en la inserción del lote
                }
    
                // Obtener el último ID insertado en la tabla lote
                $ultimoIdLote = $this->conexion->insert_id;
                echo "Nuevo lote insertado con ID: $ultimoIdLote<br>";
    
                // Cierre de la sentencia para la tabla lote
                $sentenciaLote->close();
            }
    
            // Llamar a la función crearEnvío con el ID de lote
    
        }
    
        // Cierre de recursos
        $sentenciaMatricula->close();
        $sentenciaExistencia->close();
    
        $this->crearEnvio($lote, $ultimoIdLote);
        return true;
    }

    public function crearEnvio($lote, $idLote)
    {
          $matricula = null; 
        $consultaMatricula = "SELECT DISTINCT c.matricula
                              FROM camion c
                              JOIN camionrutas cr ON c.matricula = cr.matricula
                              JOIN rutadepartamento rd ON cr.idRuta = rd.idRuta
                              WHERE rd.idDepartamento = ?";
        $sentenciaMatricula = $this->conexion->prepare($consultaMatricula);
        $sentenciaMatricula->bind_param("i", $departamento); // Cambiado a parámetro
    
        // Preparación de consulta para verificar la existencia del lote
        $consultaExistencia = "SELECT id FROM lote WHERE camion = ? AND idDepartamento = ?";
        $sentenciaExistencia = $this->conexion->prepare($consultaExistencia);
        $sentenciaExistencia->bind_param("si", $matricula, $departamento);
    
        foreach ($lote as $dato) {
            $departamento = $dato['departamento'];
            $id = $dato['id'];
    
            
            // Obtener la matrícula
            $sentenciaMatricula->execute();
            $resultadoMatricula = $sentenciaMatricula->get_result();
    
            if ($resultadoMatricula->num_rows > 0) {
                $rowMatricula = $resultadoMatricula->fetch_assoc();
                $matricula = $rowMatricula['matricula'];
                if (array_key_exists('matricula', $rowMatricula)) {
                    
                    var_dump($matricula); // Agregado para depurar
                } else {
                    echo "La clave 'matricula' no existe en el array.<br>";
                    continue; // Saltar a la siguiente iteración si no existe la clave 'matricula'
                }}
            }
        // Iterar sobre cada paquete en el lote
        foreach ($lote as $dato) {
            // Obtener información del paquete
            
            $departamento = $dato['departamento'];
            $idPaquete = $dato['id'];

            // Obtener información del paquete desde la tabla paquete
            $queryPaquete = $this->conexion->prepare("SELECT fechaIngreso, idDepartamento, idLote FROM paquete WHERE id = ?");
            $queryPaquete->bind_param('i', $idPaquete);
            $queryPaquete->execute();
            $resultPaquete = $queryPaquete->get_result();

            // Verificar si se encontró el paquete
            if ($resultPaquete->num_rows > 0) {
                // Obtener datos del paquete
                $rowPaquete = $resultPaquete->fetch_assoc();
                $fechaIngreso = $rowPaquete['fechaIngreso'];
                $idDepartamento = $rowPaquete['idDepartamento'];
                $idLote = $rowPaquete['idLote'];


                // Obtener información del almacén
                $queryAlmacen = $this->conexion->prepare("SELECT id FROM almacen WHERE idDepartamento = ?");
                $queryAlmacen->bind_param('i', $idDepartamento);
                $queryAlmacen->execute();
                $resultAlmacen = $queryAlmacen->get_result();

                // Verificar si se encontró el almacén
                if ($resultAlmacen->num_rows > 0) {
                    // Obtener datos del almacén
                    $rowAlmacen = $resultAlmacen->fetch_assoc();
                    $idAlmacenDestino = $rowAlmacen['id'];

                    // Insertar en la tabla envios con el idLote y idPaquete
                    $consultaEnvio = "INSERT INTO envios ( idPaquete, idLote,idAlmacenDestino, matricula, fechaEnvio) VALUES (?, ?, ?, ?, ?)";
                    $queryEnvio = $this->conexion->prepare($consultaEnvio);
                    $queryEnvio->bind_param('iiiss', $idPaquete, $idLote, $idAlmacenDestino, $matricula, $fechaIngreso);

                    // Ejecutar la consulta de $queryEnvio
                    if (!$queryEnvio->execute()) {
                        // Manejar el error de manera adecuada
                        var_dump("Error al insertar en envios: " . $queryEnvio->error);
                    } else {
                        var_dump("Inserción en envios exitosa.");
                    }

                    // Cerrar la declaración preparada de $queryEnvio
                    $queryEnvio->close();
                } else {
                    var_dump("No se encontró el almacén para el ID Departamento: $idDepartamento");
                }

                // Cerrar la declaración preparada de $queryAlmacen
                $queryAlmacen->close();
            } else {
                var_dump("No se encontró información para el paquete con ID: $idPaquete");
            }

            // Cerrar la declaración preparada de $queryPaquete
            $queryPaquete->close();
        }

        return true;
    }
    


 

}




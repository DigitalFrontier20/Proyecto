<?php
require_once("../DB/db.php"); // tiene conexion a BaseDatos
class departamentoModelo extends DB
{

    public function __construct()
    {
        parent::__construct();
    }
    public function buscar($idDepartamento)
    {
        $ruta = array();

        $consulta = "SELECT rutadepartamento.*, almacen.* 
                     FROM rutadepartamento
                     LEFT JOIN almacen ON rutadepartamento.idDepartamento = almacen.idDepartamento
                     WHERE rutadepartamento.idDepartamento ='$idDepartamento'";

        $resultado = $this->conexion->query($consulta);

        foreach ($resultado as $fila) {
            $ruta[] = $fila;
        }

        // var_dump($ruta);
        return $ruta;
    }


}






?>
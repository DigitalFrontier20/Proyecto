<?php
require_once("../DB/db.php"); // tiene conexion a BaseDatos
class paquetesModelo extends DB
{

    public $codigo;
    public $direccion;
    public $estado;

    public function __construct()
    {
        parent::__construct();
    }

    public function buscarLote($idLote)
    {
        $insertar = $this->conexion->query("SELECT * FROM lotes WHERE idLote='$idLote'");
        $filas = $insertar->fetch_all(MYSQLI_ASSOC);
        $lotes = array();
        foreach ($filas as $fila) {
            $lotes[] = $fila;
        }
        return $lotes;
    }


    public function buscarPaquete($idPaquete)
    {
        // Utiliza consultas preparadas para evitar inyecciones SQL
        $consulta = $this->conexion->prepare("SELECT * FROM paquete WHERE id = ?");
        $consulta->bind_param('i', $idPaquete); // 'i' indica que el valor es un entero
        $consulta->execute();

        // Obtiene el resultado de la consulta
        $resultado = $consulta->get_result();

        // Verifica si se encontró exactamente un paquete
        if ($resultado->num_rows === 1) {
            // Fetch asocia el resultado a un array asociativo
            $datosPaquete = $resultado->fetch_assoc();
            return $datosPaquete;
        } elseif ($resultado->num_rows > 1) {
            // Si hay más de un paquete con el mismo ID, maneja este caso según tus necesidades
            // Puede ser un error en la base de datos, o tal vez necesitas devolver un array con todos los paquetes encontrados.
            // Aquí se lanza una excepción como ejemplo:
            throw new Exception("Se encontraron múltiples paquetes con el mismo ID.");
        } else {
            return null; // No se encontró ningún paquete
        }
    }



    public function AgregarPaquete($ciudad, $calle, $nroPuerta, $departamento)
    {
        $fecha = array();
        // echo '<script language="javascript">alert ("Paquete registrado");  window.location="../View/funcionarioVista.php"; </script>';
        $estado = "EnAlmacen";

        $fechaIngreso = new DateTime();
        $fechaActualFormatoString = $fechaIngreso->format('Y-m-d H:i:s');
        // echo $fechaActualFormatoString;

        $sqlObtenerIntervalo = "SELECT tiempo FROM rutadepartamento WHERE idDepartamento = '$departamento'";
        $resultadoIntervalo = $this->conexion->query($sqlObtenerIntervalo);

        while ($resultado = $resultadoIntervalo->fetch_assoc()) {
            $tiempo = $resultado['tiempo'];
            $fecha[] = $tiempo;
        }

        // Imprimir el tiempo
        foreach ($fecha as $valor) {
            //echo "Tiempo: $valor<br>";
        }

        // Convertir el tiempo a segundos
        $tiempoSegundos = strtotime($valor) - strtotime('00:00:00');

        // Crear un intervalo de tiempo
        $intervalo = new DateInterval('PT' . $tiempoSegundos . 'S');

        // Sumar el intervalo a la fecha de ingreso
        $fechaEstimada = $fechaIngreso->add($intervalo);
        $fechaEstimadaString = $fechaEstimada->format('Y-m-d H:i:s');
        // Imprimir la fecha estimada
        // echo "Fecha Estimada: " . $fechaEstimada->format('Y-m-d H:i:s') . "<br>";

        // Consulta de inserción con variables correctamente formateadas
        echo '<script language="javascript">alert ("Se agrego correctamente");  window.location="../View/funcionarioVista.php";   </script>';
        $consulta = "INSERT INTO paquete (ciudad, calle, nroPuerta, estado, idDepartamento, fechaIngreso) 
        VALUES ('$ciudad', '$calle', '$nroPuerta', '$estado', '$departamento', '$fechaActualFormatoString')";
        // Ejecutar la consulta de inserción
        $resultadoInsercion = $this->conexion->query($consulta);

        return $fecha;
    }
    public function BorrarPaquete($id)
    {
        echo '<script language="javascript">alert ("Se elimino correctamente");  window.location="../View/funcionarioVista.php";   </script>';
        $query = "SELECT COUNT(*) as count FROM paquete WHERE id = '$id'";
        $result = $this->conexion->query($query);
        $row = $result->fetch_assoc();
        $query = "DELETE FROM paquete WHERE id ='$id'";
        return $this->conexion->query($query);

    }

    public function ModificarPaquete($codigo, $calle, $nropuerta,$departamento)
    {



        echo '<script language="javascript">alert ("Se Modifico correctamente");  window.location="../View/funcionarioVista.php";   </script>';
        $query = "UPDATE  paquete SET calle='$calle',  nroPuerta='$nropuerta' ,  idDepartamento='$departamento' WHERE id='$codigo'";
        return $this->conexion->query($query);


    }



    public function cerrarConexion()
    {
        $this->conexion->close();
    }
}

?>
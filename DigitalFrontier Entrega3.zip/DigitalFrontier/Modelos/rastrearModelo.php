<?php

require_once("../DB/db.php");



class rastrearModelo extends DB
{
    public $codigouser;





    public function __construct()
    {
        parent::__construct();
    }

    public function buscarPaquete($codigouser)
    {
        $codigouser = $this->conexion->real_escape_string($codigouser);
        $consulta = "SELECT * FROM paquete WHERE id='$codigouser'";
        $resultado = $this->conexion->query($consulta);

        $paquetes = array();

        if ($resultado && $resultado->num_rows > 0) {
            while ($fila = $resultado->fetch_assoc()) {
                if (isset($fila['id']) && isset($fila['estado'])) {
                    $paquetes[] = $fila;
                }
            }
        } else {
            // No se encontraron resultados
            echo "<script>alert('No se encontró ningún paquete con el ID proporcionado.');</script>";
        }

        return $paquetes;
    }
}




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Iniciar Sesion</title>


</head>

<body style="background: #E0EAFC;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #CFDEF3, #E0EAFC);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #CFDEF3, #E0EAFC); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
">

    <div class="formulario">
        <div class="div-fotologin">
            <span id="title-formprincipal">Welcome <br>
                to Youruga Express<br>
                User Area</span>
            <small class="small-login">Welcome back,Please login <br>
                to your account.</small>


        </div>

        <br>
        <section class="form">
            <form action="../Controladores/usuarioControlador.php" method="POST">
                <br>
                <br>
                <br>
                <span class="title-from">Log in</span>
                <br>
            
                <input type="hidden" name="opcion" value="login">
                <input type="text" name="ci" id="form-ci" placeholder="CI" required><br><br>
                <br>

                <input type="password" name="password" id="form-ci" placeholder="Password" required><br><br>
                <br>

                <input type="submit" value="Submit" name="btnlogin" id="btn-login">

        
            </form>

            <div id="errorMessage"></div>

        </section>

    </div>











</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <title>Almacen</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            /* Fondo de color */
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            /* Establecer la altura mínima del cuerpo como 100% del alto de la ventana */
        }

        .header-volver {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            background-color: #2a7f95;
            /* Color de fondo del encabezado */
            padding: 10px;
            color: white;

        }

        #img-volver {
            cursor: pointer;
        }

        #contenido {
            display: flex;
            flex: 1;
            width: 100%;
            /* Ajustar el fondo al 100% del ancho */
            align-items: center;
        }

        #mitad-almacen {

            background-color: #2a7f95;
            /* background: url("../img/Chivacola.jpg"); */
            /* Ocupara toda la altura disponible */
            height: calc(88.6vh);
            width: 800px;
            /* La imagen de adapte al tamaño del despoditivo */
            background-size: cover;
            /* La imagen estara centrada */
            background-position: center;
            /* Tomar la mitad del ancho del contenido */
        }

        #mitad-almacen img {
            max-width: 100%;
            max-height: 200px;
            margin-top: 20px;
            /* Altura máxima de la imagen */
        }

        .article-list {
            flex: 1;
            max-width: 400px;
            /* Ancho máximo del formulario */
            margin: auto 20%;
            padding: 40px;
            background-color: white;
            border-radius: 8px;
            box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;
        }

        #formulario-almacenes {
            text-align: center;
        }

        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        #btn {
            background-color: #2a7f95;
            color: white;
            justify-content: center;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        h2 {
            text-align: justify;
            color: #ffffff;
            font-family: monospace;
            margin: auto;
            justify-content: center;
            margin: 300px 100px;

        }

        span {
            text-align: justify;
            color: #ffffff;
            font-family: monospace;
            margin: 23% 100px;
            /* Agregar un espacio entre el h2 y el span */
            display: block;
            position: absolute;

        }

        #img-almacen {
            width: 200px;
            justify-content: center;
            margin: auto 29%;
        }

        #btn {
            margin: auto;
        }

        @media only screen and (max-width: 600px) {


            #img-volver {
                margin-bottom: 10px;
            }

            #contenido {
                padding: 10px;
            }

            #mitad-almacen h2,
            #mitad-almacen span {
                display: none;
                background-color: none;
            }

            .article-list {}


            #departamento {
                width: 100%;
                /* Haz que los input ocupen el 100% del ancho disponible */
                box-sizing: border-box;
                /* Incluye el padding y el borde en el ancho total */
                margin-bottom: 10px;
                /* Añade un pequeño espacio entre los input */
            }

            #btn {
                width: 100%;
                margin: 0;
                /* Asegura que el botón ocupe el ancho completo y no tenga margen lateral */
            }

        }
    </style>
</head>

<body>

    <header class="header-volver">
        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>
        <h1>Almacen</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>

    <div id="contenido">
        <div id="mitad-almacen">

            <h2>Yorugua Express<br> Cuenta Con Almacenes en<br> todos los departamentos.</h2>
            <span>Aqui Podras Consultar los Almacenes y sus lotes.</span>

        </div>
        <article class="article-list">
            <img src="Imagenes/varios.png" alt="Almacén" id="img-almacen">
            <form action="../Controladores/almacenesControlador.php" method="POST" id="formulario-almacenes">

                <select id="departamento" name="departamento" placeholder="Seleccione Almacen">
                    <option value="2">Soriano</option>
                    <option value="3">Canelones</option>
                    <option value="4">Durazno</option>
                    <option value="5">Florida</option>
                    <option value="6">Lavalleja</option>
                    <option value="7">San jose</option>
                    <option value="8">Treinta y Tres</option>
                    <option value="9">Flores</option>
                    <option value="10">Colonia</option>
                    <option value="11">Rio Negro</option>
                    <option value="12">Tacuarembo</option>
                    <option value="13">Cerro Largo</option>
                    <option value="14">Paysandu</option>
                    <option value="15">Rivera</option>
                    <option value="16">Salto</option>
                    <option value="17">Artigas</option>
                    <option value="18">Maldonado</option>
                    <option value="19">Rocha</option>
                </select>
                <br>
                <br>
                <input type="submit" value="Submit" name="btnlogin" id="btn">
            </form>
        </article>
    </div>

</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <header class="header-volver">

        <a href="../View/abmUsuarios.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Digital Frontier</h1>
    </header>
    <div class="container-agregarvista">
        <article>
            <img src="Imagenes/modificar-admin.png" height="200px">
        </article>
        <form action="../Controladores/usuarioControlador.php" method="POST">

            <span class="title-from">Ingrese nuevos datos del Usuario</span>
            <br>
            <br>


            <input type="hidden" name="opcion" value="modificar">
            <span>CI Del Usuario:
                <?php

                if (isset($_GET['ci'])) {
                    $ci = $_GET['ci'];
                    echo "$ci";
                }



                ?>
            </span>
            <br>
            <br>
            <input type="text" name="ci" placeholder="Ingrese CI Del Usuario" required>
            <br>
            <br>
            <input type="text" name="nombre" placeholder="Ingrese Nombre" required>
            <br>
            <br>
            <input type="text" name="password" placeholder="Ingrese password" required>
            <br>
            <br>
            <input type="text" name="tipo" placeholder="Ingrese tipo" required>
            <br>
            <br>
            <input type="submit" value="Agregar" id="btn">


        </form>


    </div>






</body>

</html>


<?php




?>
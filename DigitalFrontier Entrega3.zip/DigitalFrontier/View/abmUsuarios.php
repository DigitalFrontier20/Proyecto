﻿<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Registros</title>
    <script src="script.js"></script>
</head>

<body>

    <header class="header-volver">

        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>

    <br>
    <br>
    <br>
    <h1>Lista de usuarios</h1>
</body>

</html>

<?php
echo '<div id="containerTable1">';
echo '<section id="containerTable2">';
echo '<table>';
?>
<button id="open">
    Ingrese Usuario
</button>

<div id="modal_container" class="modal-container">
    <div class="modal">
        <form action="../Controladores/usuarioControlador.php" method="POST">

            <span class="title-from">Ingrese datos del Usuario</span>
            <br>
            <input type="hidden"  name="opcion" value="agregar">
            <br>
            <br>
            <input type="text" id="ci" name="ci" placeholder="Ingrese CI" required>
            <br>
            <br>
            <input type="text" id="ci" name="nombre" placeholder="Ingrese nombre" required>
            <br>
            <br>
            <input type="text" id="ci" name="password" placeholder="Ingrese contraseña" required>
            <br>
            <br>
            <select name="tipo" id="tipo">
                <option value="Funcionario">Funcionario</option>
                <option value="Administrador">Administrador</option>
                <option value="Camionero">Camionero</option>
            </select>
            <br>
            <br>
            <br>
            <input type="submit" value="Agregar" id="close">


        </form>
    </div>
</div>
<?php
echo '<tr id="headTable">';
echo '';
echo '<th>CI</th>';
echo '<th>Nombre</th>';
echo '<th>Contraseña</th>';
echo '<th>Tipo</th>';
echo '<th>Opciones</th>';
echo '<tr>';
function httpRequest($url)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $data = curl_exec($curl);
    return $data;
}


$dato = json_decode(httpRequest("http://localhost/DigitalFrontier/Controladores/mostrarUsuarios.php"), true);

foreach ($dato as $fila) {


    echo '<tr>';
    echo '<td>' . $fila['ci'] . '</td>';
    echo '<td>' . $fila['nombre'] . '</td>';
    echo '<td>' . $fila['password'] . '</td>';
    echo '<td>' . $fila['tipo'] . '</td>';
    echo '<td><div id="modificar"><a id="a-paquetes" href="nuevosDatosUsuario.php?ci=' . $fila['ci'] . '"><button " id="btn-modificar">Modificar</button></a></div>
    <div id="modificar"><form id="mod"action="../Controladores/usuarioControlador.php" method="POST"><input type="hidden" name="opcion" value="borrar"><input type="hidden" name="ci" value="' . $fila['ci'] . '"><button type="submit" id="btn-eliminar" name="opcion" value="borrar">Eliminar</button></form></div></td>';
    echo '<tr>';



}



echo '</div>';
echo '<br>';
echo '</table>';
echo '<br>';
echo '<br>';
echo '<br>';

echo '</div>';








?>
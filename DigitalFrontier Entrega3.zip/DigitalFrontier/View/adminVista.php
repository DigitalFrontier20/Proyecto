<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Yorugua Express</title>


</head>

<body>

    <header class="header-volver">

        <a href="../View/formulario.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>

        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>


    <div class="formulario-admin">



        <div class="cards-admin">
            <a href="../View/funcionarioVista.php">
                <button id="btn-admin">ABM Paquetes
                    <br>
                    <br>
                    <br>
                    <img src="Imagenes/paquete-admin.png" height="150px"></button>

            </a>
        </div>
        <div class="cards-admin">
            <a href="../View/abmUsuarios.php">
                <button id="btn-admin">ABM Usuaurios
                    <br>
                    <br>
                    <br>
                    <img src="Imagenes/usuarios-admin.png.png" height="150px">
                </button>
            </a>
        </div>

        <div class="cards-admin">
            <a href="../View/almacenVistaAdmin.php">
                <button id="btn-admin">Almacenes
                    <br>
                    <br>
                    <br>
                    <img src="Imagenes/almacendos.png" height="150px">
                </button>
            </a>
        </div>
        <div class="cards-admin">
            <a href="../View/camioneroVistaAdmin.php">
                <button id="btn-admin">Camioneros
                    <br>
                    <br>
                    <br>
                    <img src="Imagenes/camiones.png" height="150px">
                </button>
            </a>
        </div>


    </div>




</body>

</html>
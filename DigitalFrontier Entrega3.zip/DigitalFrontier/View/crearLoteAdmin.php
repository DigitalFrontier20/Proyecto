<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
    <title>Registros</title>
</head>
<style>
    @media only screen and (max-width:1300px) {

        /* Adjust styles for screens wider than 600px */


        #containerTable8 {
            width: 20%;
            margin: 60% -4%;
        }






        #contenedorFormulario {
            display: flex;
            flex-direction: column;

        }

        #formulario-paquetes {
            display: none;
        }



        .form-group {
            margin: 80% 1%;
            width: 60%;
        }

        #formulario-paquetes {
            display: flex;
            flex-direction: column;
        }
    }
</style>

<body>
    <header class="header-volver">
        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>

        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>
    <br><br><br>
</body>

<html>

<article id="contenedorFormulario">
    <BR>
    <form action="../Controladores/lotesControlador.php" method="POST" class="crear-lote-primera">
        <select id="departamento" name="departamento">
            <option disabled selected>Primero Debe Seleccionar el Departamento DeL Lote</option>
            <option value="2">Canelones</option>
            <option value="3">Florida</option>
            <option value="4">Durazno</option>
            <option value="5">Soriano</option>
            <option value="6">Lavalleja</option>
            <option value="7">San jose</option>
            <option value="8">Treinta y Tres</option>
            <option value="9">Flores</option>
            <option value="10">Colonia</option>
            <option value="11">Rio Negro</option>
            <option value="12">Tacuarembo</option>
            <option value="13">Cerro Largo</option>
            <option value="14">Paysandu</option>
            <option value="15">Rivera</option>
            <option value="16">Salto</option>
            <option value="17">Artigas</option>
            <option value="18">Maldonado</option>
            <option value="19">Rocha</option>
        </select>
        <input type="hidden" id="idsPaquetesSeleccionados" name="idsPaquetesSeleccionados" value="">
        <input type="submit" value="Filtrar Por Departamento" name="inputs" id="btn-mandar">
    </form>

    <div class="div-fullLotes">

        <div class="form-group">

            <form action="" method="POST">
                <input type="number" name="cant" id="codigo-agregar2"
                    placeholder="Luego Ingrese Cantidad de Paquetes Lote" required><br><br>
                <br>
                <input type="submit" value="Submit" name="inputs" id="btn-loginLotes">


            </form>
        </div>
    </div>

    <?php
    echo '<section id="containerTable8" >';
    echo '<table>';
    echo '<tr id="headTable">';
    echo '<th>ID</th>';
    echo '<th>Calle</th>';
    echo '<th>nroPuerta</th>';
    echo '<th>departamento</th>';
    echo '<th>fechaIngreso</th>';
    echo '<th>Estado</th>';
    // echo '<th>Seleccionar</th>';
    echo '<tr>';
    echo '<tr>';

    if (isset($_GET['mandar'])) {
        $mandar = $_GET['mandar'];
        $urldecode = urldecode($mandar);
        $b = json_decode($urldecode, true);

        foreach ($b as $fila) {
            echo '<tr>';
            echo '<td>' . $fila['id'] . '</td>';
            echo '<td>' . $fila['calle'] . '</td>';
            echo '<td>' . $fila['nroPuerta'] . '</td>';
            echo '<td>' . $fila['idDepartamento'] . '</td>';
            echo '<td>' . $fila['fechaIngreso'] . '</td>';
            echo '<td>' . $fila['estado'] . '</td>';
            //   echo '<td><input type="checkbox" name="seleccion[]" value="' . $fila['id'] . '"></td>';
            echo '</tr>';
        }
        echo '</section>';
        echo '<br>';
        echo '</table>';
        echo '<br>';
        echo '</div>';
    }
    ?>
</article>





<?php

if (isset($_POST['inputs'])) {
    $cant = $_POST['cant'];


    if ($cant <= 10) {
        echo '   <form id="formulario-paquetes" action="../Controladores/lotesControlador.php" method="POST">
                
            ';
        //  echo ' <input type="text" name="IdLote[]" id="codigo" placeholder="Ingrese el ID del Lote">';
        echo '<br>';

        for ($j = 1; $j <= $cant; $j++) {

            echo '<br>';
            echo 'Paquete:', "$j";
            echo '<br>';
            echo ' <input type="text" name="id[]" id="codigo" placeholder="Codigo">
              
                <select id="matricula" name="matricula[]">
                <option value="STP2325">STP2325</option>
                <option value="STP3414">STP3414</option>
                <option value="STP3434">STP3434</option>
                <option value="STP3453">STP3453</option>
                <option value="STP3563">STP3563</option>
                <option value="STP4523">STP4523</option>
            </select>
           
                <input type="text" name="departamento[]" id="codigo" placeholder="Ingrese el ID Departamento">
            ';

        }
        echo '<input type="hidden" value="agregar" name="opcion">';
        echo '<br>';
        echo '  <input type="submit" value="Submit" name="registrar" id="btn">';
    } else {
        echo '<span style="color:red;">Capacidad de paquetes por lote 10 paquetes</span>';
    }
}

?>

</form>




</article>
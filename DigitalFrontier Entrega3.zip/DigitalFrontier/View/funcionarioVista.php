<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <script src="script.js"></script>
    <title>Registros</title>
</head>

<body>

    <header class="header-volver">

        <a href="../View/formulario.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>

        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>

    <br>
    <br>
    <br>


    <?php
    echo '<div id="containerTable1">';
    echo '<section id="containerTable2">';
    echo '<table>';
    ?>
    <button id="open">
        Ingrese Paquete
    </button>

    <div id="modal_container" class="modal-container">
        <div class="modal">
            <form action="../Controladores/paquetesControlador.php" method="POST">
                <span class="title-from">Ingrese datos paquete</span>
                <br>
                <br>
                <input type="hidden" name="opcion" value="agregar">
                <input type="text" name="calle" id="codigo-agregar" placeholder="Ingrese calle" required>
                <br>
                <br>
                <input type="text" name="ciudad" id="codigo-agregar" placeholder="Ingrese Ciudad" required>
                <br>
                <br>
                <input type="text" name="nroPuerta" id="codigo-agregar" placeholder="Ingrese NroPuerta" required>
                <br>
                <br>
                <select id="codigo-agregar" name="departamento">
                    <option value="2">Canelones</option>
                    <option value="3">Florida</option>
                    <option value="4">Durazno</option>
                    <option value="5">Soriano</option>
                    <option value="6">Lavalleja</option>
                    <option value="7">San jose</option>
                    <option value="8">Treinta y Tres</option>
                    <option value="9">Flores</option>
                    <option value="10">Colonia</option>
                    <option value="11">Rio Negro</option>
                    <option value="12">Tacuarembo</option>
                    <option value="13">Cerro Largo</option>
                    <option value="14">Paysandu</option>
                    <option value="15">Rivera</option>
                    <option value="16">Salto</option>
                    <option value="17">Artigas</option>
                    <option value="18">Maldonado</option>
                    <option value="19">Rocha</option>
                </select>
                <br>
                <input type="submit" value="Agregar" id="close">


            </form>



        </div>
    </div>
    <?php
    echo '<tr id="headTable">';
    echo '<th>ID</th>';
    echo '<th>Ciudad</th>';
    echo '<th>Calle</th>';
    echo '<th>nroPuerta</th>';
    echo '<th>IDDepartamento</th>';
    echo '<th>fechaIngreso</th>';
    echo '<th>IdLote</th>';
    echo '<th>Estado</th>'; 
    echo '<th>Opciones</th>';
    echo '<tr>';

    function httpRequest($url)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($curl);
        return $data;
    }

    $dato = json_decode(httpRequest("http://localhost/DigitalFrontier/Controladores/mostrar.php"), true);

    // Configuración de paginación
    
    foreach ($dato as $fila) {
        echo '<tr>';
        echo '<td>' . $fila['id'] . '</td>';
        echo '<td>' . $fila['ciudad'] . '</td>';
        echo '<td>' . $fila['calle'] . '</td>';
        echo '<td>' . $fila['nroPuerta'] . '</td>';
        echo '<td>' . $fila['idDepartamento'] . '</td>';
        echo '<td>' . $fila['fechaIngreso'] . '</td>';
        echo '<td>' . $fila['idLote'] . '</td>';
        echo '<td>' . $fila['estado'] . '</td>';
        
        
        echo '<td ><div id="modificar"><a id="a-paquetes" href="nuevosdatos.php?id=' . $fila['id'] . '"><button onclick="window.modal.showModal();" id="btn-modificar">Modificar</button></a></div> 
  <div id="modificar"><form id="mod"action="../Controladores/paquetesControlador.php" method="POST"><input type="hidden" name="opcion" value="borrar"><input type="hidden" name="id" value="' . $fila['id'] . '"><button type="submit" id="btn-eliminar" name="opcion" value="borrar">Eliminar</button></form></div></td>';
        echo '</tr>';
    }

    echo '<th>';

    echo '</section>';
    echo '<br>';

    echo '</table>';

    echo '</div>';
    echo '<br>';
    echo '</div>';

    // Mostrar los controles de paginación
    

    ?>



    <div class="div-full">
        <div class="divUsuario3">
            <span class="title-div">Crear Lote</span>
            <br>
            <br>

            <a href="../View/crearLote.php">

                <img id="fondo-svg2" src="Imagenes/lotes.png" height="100px">
            </a>
        </div>

        <div class="divUsuario4">
            <span class="title-div">Ir Almacen</span>
            <br>
            <br>

            <a href="../View/almacen.php">

                <img id="fondo-svg2" src="Imagenes/almacen.png" height="100px">
            </a>
        </div>
    </div>

    </div>

</body>

</html>
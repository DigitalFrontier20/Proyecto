<?php

session_start();

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Redirige a la página de inicio de sesión si no está autenticado
    header("Location: inicio_sesion.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Camiones</title>
</head>

<body>

    <header class="header-volver">
        <a
            href="camioneroMostrar.php<?php if (isset($_GET['mandar']))
                echo '?mandar=' . urlencode($_GET['mandar']); ?>">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>

    <br>
    <br>
    <br>

    <?php


    if (isset($_GET["mandar"])) {
        $mandar = $_GET['mandar'];
        $urldecode = urldecode($mandar);
        $imprimir = json_decode($urldecode, true);

        //var_dump($imprimir); // Agrega esta línea para depurar
    
        echo '<div id="containerTable1">';
        echo '<div id="containerTable7">';


        echo '<table>';
        echo '<tr id="headTable">';
        echo '<th>Matricula</th>';
        echo '<th>Estado</th>';
        echo '<th>Cedula</th>';
        echo '<th>IdRuta</th>';
        echo '<th>Opciones</th>';
        echo '<tr>';
        foreach ($imprimir as $elemento) {
            echo '<tr>';
            echo '<td style="vertical-align: middle;">' . $elemento['matricula'] . '</td>';
            echo '<td>' . $elemento['estado'] . '</td>';
            echo '<td>' . $elemento['ciCamionero'] . '</td>';
            // echo '<td>' . $elemento['idRuta'] . '</td>';
            // echo '<td>' . $almacen['idDepartamento'] . '</td>';
            echo '<td>';
            echo '<div id="opciones-camionero"><a href="../Controladores/camionerosControlador.php?matricula= ' . $elemento['matricula'] . '"><button id="btn-ver"  value="verlotes" name="accion"> Ver Lote</button></a></div>';
            echo '</td>';
            echo '</tr>';

            

        }

        echo '</div>';
        echo '<br>';
        echo '</table>';
        echo '<br>';
        echo '<br>';
        echo '<br>';

        echo '</div>';
    }


    ?>
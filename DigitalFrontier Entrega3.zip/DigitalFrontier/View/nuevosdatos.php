<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <header class="header-volver">

        <a href="../View/funcionarioVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Digital Frontier</h1>
    </header>
    <div class="container-agregarvista">
        <article>
            <img src="Imagenes/paquete-modificar.png" height="200px">
        </article>
        <form action="../Controladores/paquetesControlador.php" method="POST">

            <span class="title-from">Ingrese nuevos datos del paquete</span>
            <br>
            <br>
            <br>
            <input type="hidden" name="opcion" value="modificar">
            <span>Codigo Del Paquete:
                <?php
                if (isset($_GET["id"])) {
                    $id = $_GET['id'];
                    echo "$id";
                }
                ?>
            </span>
            <br>
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <br>
            <br>
            <input type="text" name="calle" id="nuevadireccion" placeholder="Ingrese Calle" required>
            <br>
            <br>
            <input type="text" name="nropuerta" id="nuevoestado" placeholder="Ingrese NroPuerta" required>
            <br>
            <br>
            <select id="codigo-agregar" name="departamento">
                    <option value="2">Canelones</option>
                    <option value="3">Florida</option>
                    <option value="4">Durazno</option>
                    <option value="5">Soriano</option>
                    <option value="6">Lavalleja</option>
                    <option value="7">San jose</option>
                    <option value="8">Treinta y Tres</option>
                    <option value="9">Flores</option>
                    <option value="10">Colonia</option>
                    <option value="11">Rio Negro</option>
                    <option value="12">Tacuarembo</option>
                    <option value="13">Cerro Largo</option>
                    <option value="14">Paysandu</option>
                    <option value="15">Rivera</option>
                    <option value="16">Salto</option>
                    <option value="17">Artigas</option>
                    <option value="18">Maldonado</option>
                    <option value="19">Rocha</option>
                </select>
            <br>
            <input type="submit" value="modificar" id="btn" name="agregar-datosuser">


        </form>


    </div>






</body>

</html>
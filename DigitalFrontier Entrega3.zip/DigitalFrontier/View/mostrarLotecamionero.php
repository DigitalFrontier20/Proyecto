<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Lote</title>
</head>

<body>

    <header class="header-volver">
        <a href="javascript:history.back()">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>

    <br>
    <br>
    <br>

    <div class="container-mostrar-datosalmacen">
        <h2>Ruta y Departamento Del Almacen</h2>

        <?php
        // Bloque para 'mandar'
        if (isset($_GET["mandar"])) {
            $mandar = $_GET['mandar'];
            $json = json_decode(urldecode($mandar), true);

            echo '<div id="containerTable1">';
            echo '<div id="containerTable10">';
            echo '<table>';
            echo '<tr id="headTable">';
            echo '<th>ID</th>';
            echo '<th>camion</th>';
            echo '<th>idDepartamento</th>';
            echo '<th>Ver Departamento y Ruta</th>';
            echo '<tr>';
            foreach ($json as $almacen) {
                echo '<tr>';
                echo '<td>' . $almacen['id'] . '</td>';
                echo '<td>' . $almacen['camion'] . '</td>';
                echo '<td>' . $almacen['idDepartamento'] . '</td>';
                echo '<td>';
                echo '<div id="modificar"><form action="../Controladores/departamentoControlador.php" method="GET"><input type="hidden" name="idDepartamento" value="' . $almacen['idDepartamento'] . '"><button type="submit" id="btn-modificar">Ver Ruta</button></form></div>';
                echo '<a href="../Controladores/camionesControlador.php?id=' . $almacen['id'] . '&accion=iniciar"><button id="btn-Iniciar">Iniciar Viaje</button></a>';
                echo '<a href="../Controladores/camionesControlador.php?id=' . $almacen['id'] . '&accion=finalizar"><button id="btn-finalizar">Finalizar Viaje</button></a>';
                echo '</td>';
                echo '</tr>';
            }
            
            echo '</div>';
            echo '<br>';
            echo '</table>';
            echo '<br>';
            echo '<br>';
            echo '<br>';
    
            echo '</div>';
        }

        // Bloque para 'dato'
        if (isset($_GET["dato"])) {
            $dato = $_GET['dato'];
            $json = json_decode(urldecode($dato), true);

            echo '<div id="containerTable1">';
            echo '<div id="containerTable7">';
            echo '<table>';
            echo '<tr id="headTable">';
            echo '<th>IDAlmacen</th>';
            echo '<th>idRuta</th>';
            echo '<th>idDepartamento</th>';
            echo '<th>Calle</th>';
            echo '<th>NroPuerta</th>';
            echo '<th>Ciudad</th>';
            echo '<tr>';
            foreach ($json as $almacen) {
                echo '<tr>';
                echo '<td>' . $almacen['id'] . '</td>';
                echo '<td>' . $almacen['idRuta'] . '</td>';
                echo '<td>' . $almacen['idDepartamento'] . '</td>';
                echo '<td>' . $almacen['calle'] . '</td>';
                echo '<td>' . $almacen['nroPuerta'] . '</td>';
                echo '<td>' . $almacen['ciudad'] . '</td>';
                echo '</tr>';
            }
            echo '</table>';
            echo '<br>';
            echo '</div>';
            echo '</div>';
        }
        ?>

    </div>
</body>

</html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <script src="script.js"></script>
    <script
	src="https://code.jquery.com/jquery-3.3.1.min.js"
	integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
	crossorigin="anonymous"></script>
    <title>Registros</title>
</head>
<body>
    <header class="header-volver">
        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>

        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>
    <br><br><br>
</body>

<html>
<?php
        echo '<div id="containerTable1">';
    ?>
        <article id="contenedorFormulario">
            <form action="../Controladores/lotesControlador.php" method="POST" class="crear-lote-primera">
                <select id="idRuta" name="idRuta">
                    <option disabled selected>Filtrar por Ruta</option>
                    <option value="1">Ruta 1</option>
                    <option value="2">Ruta 2</option>
                    <option value="3">Ruta 3</option>
                    <option value="4">Ruta 4</option>
                    <option value="5">Ruta 5</option>
                    <option value="6">Ruta 6</option>
                    <option value="7">Ruta 7</option>
                    <option value="8">Ruta 8</option>
                    <option value="9">Ruta 9</option>
                </select>
                <input type="submit" value="Filtrar por ruta" name="inputs" id="btn-mandar" >
            </form>
        </article>

        <?php
            echo '<section id="containerTable8" >';
            echo '<table>'; 
            echo '<tr id="headTable">';
            echo '<th>ID Lote</th>';
            echo '<th>Departamento</th>';
            echo '<th>Seleccionar</th>';
            echo '<tr>';
            echo '<tr>';

            if (isset($_GET['mandar'])) {
            $mandar = $_GET['mandar'];
            $urldecode = urldecode($mandar);
            $b = json_decode($urldecode, true);

            foreach ($b as $fila) { 
                echo '<tr>';
                echo '<td>' . $fila['id'] . '</td>';
                echo '<td>' . $fila['idDepartamento'] . '</td>';
                echo '<td><input type="checkbox" name="seleccion[]" value="' . $fila['id'] . '"></td>';
                echo '</tr>';
            }
            echo '</section>';
            echo '<br>';
            echo '</table>';
            echo '<br>';
            echo '</div>';
            }
        ?>

<script type="text/javascript">
	$(document).ready(function(){
		
		recargarLista();

		$('#lista1').change(function(){
			recargarLista();
		});
	})
</script>
<script type="text/javascript">
	function recargarLista(){
		$.ajax({
			type:"POST",
			url:"../Controladores/datosCamiones.php",
			data:"idRuta=" + $('#lista1').val(),
			success:function(r){
				$('#select2lista').html(r);
               
			}
		});
	}
</script>



<button id="open">
        Asignar Camion
    </button>
    <div id="modal_container" class="modal-container">
            <div class="modal">
                <form action="" method="POST" >
                    <span class="title-from">Ingrese datos Lote</span>
                    <br>
                    <br>
                    <br>
                    
			<select id="lista1" name="lista1">
            <option value="0">Camiones por Ruta</option>
				<option value="1">Ruta1</option>
				<option value="2">Ruta2</option>
				<option value="3">Ruta3</option>
				<option value="4">Ruta4</option>
				<option value="5">Ruta5</option>
                <option value="2">Ruta6</option>
				<option value="3">Ruta7</option>
				<option value="4">Ruta8</option>
				<option value="5">Ruta9</option>
			</select>
			<br>
			<div id="select2lista"></div>
                    <br>
                <input type="submit"  value="Agregar" id="close" onclick="return visualizarLotes()" >
                </form>
        </div>
        </div>
        <br>

</body>
</html>


            

</body>
</html>


          



       
</body>
</html>

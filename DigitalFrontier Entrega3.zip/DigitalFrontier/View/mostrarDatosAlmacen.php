<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Almacenes</title>
</head>
<style>
    @media only screen and (max-width: 600px) {
       
        #containerTable7{
            width: 20%;
            margin: auto -10%;
        }
        table {
            font-size: 14px;
        }

        th,
        td {
            padding: 8px;
        }
    }
</style>







<body>

    <header class="header-volver">

        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>

    <br>
    <br>
    <br>

    <div class="container-mostrar-datosalmacen">
        <h2>
            Lotes En El Almacen
        </h2>
        <?php

        if (isset($_GET['dato'])) {
            $dato = $_GET['dato'];
            $urldecode = urldecode($dato);

            $imprimir = json_decode($urldecode, true);


            echo '<div id="containerTable1">';
            echo '<div id="containerTable7">';


            echo '<table>';
            echo '<tr id="headTable">';
            echo '<th>IDAlmacen</th>';
            echo '<th>Calle</th>';
            echo '<th>NroPuerta</th>';
            echo '<th>Departamento</th>';
            echo '<th>Ciudad</th>';
            echo '<th>Ver Paquetes En El Lote</th>';
            echo '<tr>';

            foreach ($imprimir as $almacen) {
                echo '<tr>';
                echo '<td>' . $almacen['id'];
                '</td>';
                echo '<td>' . $almacen['calle'];
                '</td>';
                echo '<td>' . $almacen['nroPuerta'];
                '</td>';
                echo '<td>' . $almacen['idDepartamento'];
                '</td>';
                echo '<td>' . $almacen['ciudad'];
                '</td>';
                echo '<td>';
                echo '<a href="../Controladores/lotesControlador.php?idDepartamento= ' . $almacen['idDepartamento'] . '"><button id="btn"> Ver Lote</button></a>';
                '</td>';
                echo '<td>';
                echo '</tr>';
            }



            echo '</div>';
            echo '<br>';
            echo '</table>';
            echo '<br>';
            echo '<br>';
            echo '<br>';

            echo '</div>';


        }

        ?>





    </div>
</body>

</html>
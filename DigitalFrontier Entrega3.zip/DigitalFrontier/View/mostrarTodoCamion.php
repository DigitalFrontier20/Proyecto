<?php

session_start();

// Verifica si el usuario está autenticado
if (!isset($_SESSION['usuario'])) {
    // Redirige a la página de inicio de sesión si no está autenticado
    header("Location: inicio_sesion.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Camiones</title>
</head>

<body>

    <header class="header-volver">
        <a href="camioneroMostrar.php<?php if (isset($_GET['mandar']))
            echo '?mandar=' . urlencode($_GET['mandar']); ?>">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>
    <?php

    if (isset($_GET["mandar"])) {
        $mandar = $_GET['mandar'];
        $urldecodificada = urldecode($mandar);
        $decodificar = json_decode($urldecodificada, true);

        // var_dump($decodificar);
        echo '<div id="containerTable1">';
        echo '<div id="containerTable7">';


        echo '<table>';
        echo '<tr id="headTable">';
        echo '<th>idDepartamento</th>';
        echo '<th> Departamento</th>';
        echo '<th>idRuta</th>';
        echo '<th>tiempo</th>';
        echo '<tr>';
        foreach ($decodificar as $value) {
            echo '<tr>';
            echo '<td>' . $value['idDepartamento'];
            '<td>';
            echo '<td>' . $value['nombre'];
            '<td>';
            echo '<td>' . $value['idRuta'];
            '<td>';
            echo '<td>' . $value['tiempo'];
            '<td>';
            echo '<tr>';
        }
    }


    ?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Mapa simple de OpenStreetMap con Leaflet</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.0.3/dist/leaflet.css">
</head>

<body>
    <header class="header-volver">

        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">
    </header>
    <script src="https://unpkg.com/leaflet@1.0.3/dist/leaflet.js"></script>
    <link rel="stylesheet" href="leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <script src="leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
    <div id="map" class="map map-home" style="margin:12px 0 12px 0;height:1000px;"></div>
    <script>
        var osmUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            osmAttrib = '&copy; <a href="http://openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            osm = L.tileLayer(osmUrl, { maxZoom: 18, attribution: osmAttrib });
        var map = L.map('map').setView([-34.903427, -56.164157], 17).addLayer(osm);
        L.marker([-34.903427, -56.164157])
            .addTo(map)
            .bindPopup('Almacen1.')
            .openPopup();

        // Define las coordenadas de inicio y fin de la ruta
        var startLatLng = L.latLng(-34.903427, -56.164157);
        var endLatLng = L.latLng(-34.889528, -56.068650);

        // Añade un marcador al inicio y fin de la ruta
        L.marker(startLatLng).addTo(map)
            .bindPopup('Inicio de la Ruta');
        L.marker(endLatLng).addTo(map)
            .bindPopup('Fin de la Ruta');

        // Configura la solicitud a OpenRouteService
        var routeUrl = 'https://api.openrouteservice.org/v2/directions/driving-car?api_key=TU_CLAVE_AQUI&start=' +
            startLatLng.lng + ',' + startLatLng.lat + '&end=' + endLatLng.lng + ',' + endLatLng.lat;

        // Realiza la solicitud de enrutamiento a OpenRouteService



        L.Routing.control({
            waypoints: [
                L.latLng(-34.903427, -56.164157), //dirección obtenida del usuario
                L.latLng(-34.889528, -56.068650) //dirección fija de destino
            ],
            language: 'es'
        }).addTo(map);
    </script>
</body>

</html>
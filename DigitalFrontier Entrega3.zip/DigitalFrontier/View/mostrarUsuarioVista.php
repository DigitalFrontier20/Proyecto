<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Registros</title>
</head>

<body>

    <header class="header-volver">

        <a href="../View/index.html">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Rastrear Paquete</h1>
    </header>

    <br>
    <br>
    <br>
</body>

</html>



<?php
if (isset($_GET["dato"])) {
    $dato = $_GET['dato'];
    $urldecode = urldecode($dato);
    $a = json_decode($urldecode, true);



    echo '<div class="container-mostrr-usuario">';
    foreach ($a as $value) {
        if (isset($value['estado']) and isset($value['id'])) {
            $estado = $value['estado'];

            // Añadir esta línea para depurar
            //      var_dump($estado);

            $id = $value['id'];
            echo "El paquete  $id  está en  " . $estado;
            echo '<br>';

            if ($estado == 'En Camino') {
                echo '<img id="gif-camion" src="Imagenes/camion-de-reparto.gif">';
            } elseif ($estado == 'Entregado') {
                echo '<br> <img id="gif-camion" src="Imagenes/155998-OVWJKP-626.jpg">';
            } elseif ($estado == 'En Almacen') {
                echo '<br> <img id="gif-camion" src="Imagenes/almacen.gif">';
            }
        }
    }
    echo '</div>';
}
?>

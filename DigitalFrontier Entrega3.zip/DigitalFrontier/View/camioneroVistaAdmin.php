<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <script src="script.js"></script>
    <title>Camiones</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            /* Fondo de color */
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            /* Establecer la altura mínima del cuerpo como 100% del alto de la ventana */
        }

        .header-volver {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            background-color: #2a7f95;
            /* Color de fondo del encabezado */
            padding: 10px;
            color: white;

        }

        #img-volver {
            cursor: pointer;
        }

        #contenido {
            display: flex;
            flex: 1;
            width: 100%;
            /* Ajustar el fondo al 100% del ancho */
            align-items: center;
        }



        #mitad-almacen img {
            max-width: 100%;
            max-height: 200px;
            margin-top: 20px;
            /* Altura máxima de la imagen */
        }

        .article-list {
            flex: 1;
            max-width: 400px;
            /* Ancho máximo del formulario */
            margin: auto 20%;
            padding: 40px;
            background-color: white;
            border-radius: 8px;
            box-shadow: rgba(0, 0, 0, 0.56) 0px 22px 70px 4px;
        }

        #formulario-almacenes {
            text-align: center;
        }

        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            box-sizing: border-box;
        }

        #btn {
            background-color: #2a7f95;
            color: white;
            justify-content: center;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        h2 {
            text-align: justify;
            color: #ffffff;
            font-family: monospace;
            margin: auto;
            justify-content: center;
            margin: 300px 100px;

        }

        span {
            text-align: justify;
            color: #ffffff;
            font-family: monospace;
            margin: 23% 100px;
            /* Agregar un espacio entre el h2 y el span */
            display: block;
            position: absolute;

        }

        #mitad-almacen {

            background-color: #2a7f95;
            /* background: url("../img/Chivacola.jpg"); */
            /* Ocupara toda la altura disponible */
            height: calc(88.6vh);
            width: 800px;
            /* La imagen de adapte al tamaño del despoditivo */
            background-size: cover;
            /* La imagen estara centrada */
            background-position: center;
            /* Tomar la mitad del ancho del contenido */
        }




        #btn {
            margin: auto;
        }

        #containerTable10 {
            width: 100%;
            font-size: 1.1em;
        }

        @media only screen and (max-width:1300px) {
            #mitad-almacen {

                background-color: #2a7f95;
                /* background: url("../img/Chivacola.jpg"); */
                /* Ocupara toda la altura disponible */
                height: calc(88.6vh);
                width: 300px;
                /* La imagen de adapte al tamaño del despoditivo */
                background-size: cover;
                /* La imagen estara centrada */
                background-position: center;
                /* Tomar la mitad del ancho del contenido */
            }

            span {
                text-align: justify;
                color: #ffffff;
                font-family: monospace;
                margin: 23% 1%;
                /* Agregar un espacio entre el h2 y el span */
                display: block;
                position: absolute;

            }

            h2 {
                text-align: justify;
                color: #ffffff;
                font-family: monospace;
                margin: auto;
                justify-content: center;
                margin: 310px 4px;

            }

            @media only screen and (max-width: 600px) {
                #mitad-almacen {
                    display: none;
                }
                table {
                font-size: 14px;
            }

            th, td {
                padding: 8px;
            }
            }
        }
    </style>
</head>

<body>
    <header class="header-volver">
        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">
        </a>
        <h1>Yorugua Express</h1>
        <img src="Imagenes/logo.png" height="90px" style="padding-right:10px">

    </header>

    <div id="contenido">
        <div id="mitad-almacen">

            <h2>Bienvenido,aqui veras todos los camiones que cuenta Yorugua Express.</h2>
            <span>Aqui podras Asignar un Camion a un chofer</span>

        </div>
        <?php

        echo '<div id="containerTable9">';


        echo '<table>';
        echo '<tr id="headTable">';
        echo '<th>CI</th>';
        echo '<th>Nombre</th>';
        echo '<tr>';

        function httpRequest($url)
        {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $data = curl_exec($curl);
            return json_decode($data, true);
        }

        $datoCamioneros = httpRequest("http://localhost/DigitalFrontier/Controladores/mostrarCamioneros.php");

        foreach ($datoCamioneros as $fila) {
            echo '<tr>';
            echo '<td>' . $fila['ci'] . '</td>';
            echo '<td>' . $fila['nombre'] . '</td>';
            echo '<tr>';
        }

        echo '</div>';
        echo '<br>';
        echo '</table>';



        ?>







        <?php
        echo '<div id="containerTable">';
        echo '<div id="containerTable10">';

        echo '<span class="title-from">Camioneros</span>';
        echo '<br>';
        echo '<br>';
        echo '<table>';
        echo '<tr id="headTable">';
        echo '<th>Matricula</th>';
        echo '<th>CI Caminero</th>';




        echo '<tr>';

        function httpRequest2($url)
        {
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $data = curl_exec($curl);
            return $data;
        }


        $dato = json_decode(httpRequest2("http://localhost/DigitalFrontier/Controladores/mostrarCamiones.php"), true);

        foreach ($dato as $fila) {


            echo '<tr>';
            echo '<td>' . $fila['matricula'] . '</td>';
            // echo '<td>' . $fila['estado'] . '</td>';
            echo '<td>' . $fila['ciCamionero'] . '</td>';

            echo '<tr>';


        }




        echo '<br>';
        echo '</table>';


        echo '</div>';
        echo '</div>';

        ?>
        <div class="class">
            <button id="openModal1">Agregar Nuevo Camion</button>

            <div id="modal1" class="modal">

                <form action="../Controladores/camionesControlador.php" method="POST">

                    <br>
                    <br>
                    <input type="hidden" name="opcion" value="agregar">
                    <br>
                    <input type="text" name="matricula" id="codigo-agregar" placeholder="Ingrese Matricula" required>
                    <br>
                    <select name="idRuta">
                        <option value="1">Ruta 1</option>
                        <option value="2">Ruta 2</option>
                        <option value="3">Ruta 3</option>
                        <option value="4">Ruta 4</option>
                        <option value="5">Ruta 5</option>
                        <option value="6">Ruta 6</option>
                        <option value="7">Ruta 7</option>
                        <option value="8">Ruta 8</option>
                        <option value="9">Ruta 9</option>
                    </select>
                    <br>
                    <br>
                    <input type="submit" value="Agregar" id="close">
                    <br>
                    <br>
                    <br>
                </form>
                <button id="closeModal1">Cerrar</button>


            </div>

            <button id="openModal2">Asignar Camionero a Camion</button>
            <div id="modal2" class="modal">
                <form action="../Controladores/camionesControlador.php" method="POST">

                    <br>
                    <br>
                    <img src="Imagenes/chofer.png" height="80px">
                    <br>
                    <br>
                    <input type="text" name="ci" id="codigo-agregar" placeholder="Ingrese CI del Camionero">
                    <br>
                    <br>
                    <input type="text" name="matricula" id="codigo-agregar" placeholder="Ingrese Matricula del Camion">
                    <br>
                    <br>
                    <input type="submit" id="close">
                </form>
                <button id="closeModal2">Cerrar</button>
            </div>
        </div>
        <style>
            /* Estilos para las ventanas modales */
            .modal {
                display: none;
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                padding: 20px;
                background-color: #fff;
                border: 1px solid #ccc;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                z-index: 1000;
            }

            /* Estilo para el fondo oscuro detrás de la ventana modal */
            .modal-background {
                display: none;
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                z-index: 999;
            }

            .class {
                display: flex;
                flex-direction: row;
                justify-content: center;
                text-align: center;
            }
        </style>
        </head>

        <body>




            <!-- Fondo oscuro detrás de las ventanas modales -->
            <div id="modalBackground" class="modal-background"></div>






            <script>
                // Funciones para mostrar y ocultar las ventanas modales
                function showModal(modalId) {
                    document.getElementById(modalId).style.display = 'block';
                    document.getElementById('modalBackground').style.display = 'block';
                }

                function closeModal(modalId) {
                    document.getElementById(modalId).style.display = 'none';
                    document.getElementById('modalBackground').style.display = 'none';
                }

                // Asignar eventos a los botones
                document.getElementById('openModal1').addEventListener('click', function () {
                    showModal('modal1');
                });

                document.getElementById('closeModal1').addEventListener('click', function () {
                    closeModal('modal1');
                });

                document.getElementById('openModal2').addEventListener('click', function () {
                    showModal('modal2');
                });

                document.getElementById('closeModal2').addEventListener('click', function () {
                    closeModal('modal2');
                });
            </script>
    </div>
</body>

</html>
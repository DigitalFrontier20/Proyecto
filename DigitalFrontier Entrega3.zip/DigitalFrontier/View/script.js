document.addEventListener('DOMContentLoaded', function() {
    // Your script code here
    const open = document.getElementById('open');
    const modal_container = document.getElementById('modal_container');
    const close = document.getElementById('close');

    open.addEventListener('click', () => {
        modal_container.classList.add('show');
    });

    close.addEventListener('click', () => {
        modal_container.classList.remove('show');
    });
});






function crearLote() {
    var departamento = document.getElementById("departamento").value;
    var formData = new FormData();
    formData.append("departamento", departamento);

    fetch("../Controladores/lotesControlador.php", {
        method: "POST",
        body: formData,
    })
        .then(response => response.json())
        .then(data => {
            // Recibe la respuesta del controlador de lotes
            // La variable 'data' ahora contiene la información del lote creado
            console.log("ID del lote creado:", data.idLote);

            // Actualiza el campo oculto con el ID del lote
            document.getElementById("idLoteInput").value = data.idLote;

            // Ahora puedes enviar el formulario de paquetes con el ID del lote
            document.getElementById("loteForm").submit();
        })
        .catch(error => console.error("Error:", error));
}


function visualizarPaquetes() {
    // Obtener todos los checkboxes con el nombre 'seleccion[]'
    var checkboxes = document.querySelectorAll('input[name="seleccion[]"]:checked');
    var idDepartamento = document.getElementById('codigo-agregar').value;

    
    // Obtener los valores (IDs) de los checkboxes seleccionados
    var seleccionados = Array.from(checkboxes).map(function (checkbox) {
        return checkbox.value;
    });

    // Mostrar los IDs en la consola (puedes ajustar esta parte según tus necesidades)
    
   

    // Puedes enviar los IDs al servidor aquí (usando AJAX o un formulario)
    // ...
   
    // Construir la URL con los IDs como parámetro
   
    var url = `../Controladores/lotesControlador.php?idsD=${encodeURIComponent(seleccionados.join(','))}&idDepartamento=${encodeURIComponent(idDepartamento)}`;
    
    console.log("URL a redirigir:", url);
    var visualizacionDiv = document.getElementById('visualizacionIDs');
    visualizacionDiv.textContent = "IDs Seleccionados: " + url;

    // Redirigir a la URL
    window.location.href = url;
}


function visualizarLotes() {
    var checkboxes = document.querySelectorAll('input[name="seleccion[]"]:checked');
    
    // Obtener los valores (IDs) de los checkboxes seleccionados
    var seleccionados = Array.from(checkboxes).map(function (checkbox) {
        return checkbox.value;
    });

    var matriculaSeleccionada = $('#select2lista option:selected').val();

    // Obtener la matrícula seleccionada y actualizar la variable matricula
    
    matricula = matriculaSeleccionada;

    // Construir la URL con los IDs como parámetro
    var url = `../Controladores/lotesControlador.php?ids=${encodeURIComponent(seleccionados.join(','))}&matriculaCamion=${encodeURIComponent(matriculaSeleccionada)}`;
   

    // Puedes realizar acciones adicionales aquí si es necesario

    // Redirigir a la URL
    window.location.href = url;

    return false; // Esto evita que el formulario se envíe por sí mismo
}
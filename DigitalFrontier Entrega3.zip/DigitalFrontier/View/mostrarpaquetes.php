<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="shortcut icon" href="Imagenes/ico.ico">
    <title>Almacenes</title>
</head>

<body>

    <header class="header-volver">

        <a href="../View/adminVista.php">
            <img id="img-volver" src="Imagenes/hacia-atras.png" height="40px">

        </a>
        <h1>Yorugua Express</h1>
    </header>

    <br>
    <br>
    <br>

    <div class="container-mostrar-datosalmacen">
        <h2>
            Paquetes Dentro Del Lote
        </h2>
        <?php

        if (isset($_GET['datos'])) {
            $datos = $_GET['datos'];
            $urldecode = urldecode($datos);

            $a = json_decode($urldecode, true);


            echo '<div id="containerTable1">';
            echo '<div id="containerTable3">';


            echo '<table>';
            echo '<tr codigo="headTable">';
            echo '<th>IDLote</th>';
            echo '<th>Direccion</th>';
            echo '<th>Codigo</th>';
            echo '<th>Estado</th>';
            echo '<tr>';

            foreach ($a as $f) {
                echo '<tr>';
                echo '<td>' . $f["idLote"];
                echo '</td>';
                echo '<td>' . $f["direccion"];
                echo '</td>';
                echo '<td>' . $f["codigo"];
                echo '</td>';
                echo '<td>' . $f["estado"];
                echo '</td>';
                echo '<tr>';
            }


            echo '</div>';
            echo '<br>';
            echo '</table>';
            echo '</div>';


            if (isset($_GET['error'])) {
                $error = $_GET['error'];
                echo '<div class="error">' . $error . '</div>';
            }

        }
        ?>








    </div>
</body>

</html>
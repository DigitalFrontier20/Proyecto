-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-11-2023 a las 04:46:14
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `almacen`
--

CREATE TABLE `almacen` (
  `id` int(11) NOT NULL,
  `calle` varchar(50) NOT NULL,
  `nroPuerta` varchar(50) NOT NULL,
  `idDepartamento` int(11) NOT NULL,
  `ciudad` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `almacen`
--

INSERT INTO `almacen` (`id`, `calle`, `nroPuerta`, `idDepartamento`, `ciudad`) VALUES
(1, 'Aconcagua', '2232', 1, 'Montevideo'),
(2, 'Ramon', '3032', 2, 'Canelones'),
(3, 'Comercio', '2121', 3, 'Florida'),
(4, 'Solis', '5227', 4, 'Durazno'),
(5, 'Amadeu', '5002', 5, 'Soriano'),
(6, 'Missouri', '4224', 6, 'Lavalleja'),
(7, 'Av.Rivera', '2323', 7, 'San Jose'),
(8, 'Solano Lopez', '5445', 8, 'Treinta y Tres'),
(9, 'Av Italia', '8998', 9, 'Flores'),
(10, 'Francisco Simon', '3421', 10, 'Colonia'),
(11, 'Rio Negro', '3113', 11, 'FRASA'),
(12, 'Mississipi', '5676', 12, 'Tacuarembo'),
(13, 'Cabrera', '3552', 13, 'Cerro Largo'),
(14, 'Asamblea', '8363', 14, 'Paysandu'),
(15, 'Av Bolivia', '9256', 15, 'Rivera'),
(16, 'Zabala Muniz', '6641', 16, 'Salto'),
(17, 'Yi', '4262', 17, 'Artigas'),
(18, 'Igua', '5322', 17, 'Maldonado'),
(19, 'Bulevar Artigas', '3333', 18, 'Rocha');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `camion`
--

CREATE TABLE `camion` (
  `matricula` varchar(7) NOT NULL,
  `ciCamionero` int(11) DEFAULT NULL,
  `estado` varchar(50) NOT NULL DEFAULT 'En Almacen'
) ;

--
-- Volcado de datos para la tabla `camion`
--

INSERT INTO `camion` (`matricula`, `ciCamionero`, `estado`) VALUES
('STP3548', 45956735, 'En Almacen'),
('STP4545', 45987735, 'En Almacen'),
('STP4678', 64254642, 'En Almacen'),
('STP5534', NULL, 'En Almacen'),
('STP6325', 32652155, 'Entregado'),
('STP6556', NULL, 'En Almacen'),
('STP6584', NULL, 'En Almacen'),
('STP7546', NULL, 'En Almacen'),
('STP8346', NULL, 'En Almacen'),
('STP8779', NULL, 'En Almacen'),
('STP9321', NULL, 'En Almacen');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `camionrutas`
--

CREATE TABLE `camionrutas` (
  `matricula` varchar(7) NOT NULL,
  `idRuta` int(11) NOT NULL
) ;

--
-- Volcado de datos para la tabla `camionrutas`
--

INSERT INTO `camionrutas` (`matricula`, `idRuta`) VALUES
('STP3548', 1),
('STP4545', 2),
('STP4678', 3),
('STP5534', 4),
('STP6325', 5),
('STP6556', 6),
('STP6584', 7),
('STP7546', 8),
('STP8346', 9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`id`, `nombre`) VALUES
(1, 'Montevideo'),
(2, 'Canelones'),
(3, 'Florida'),
(4, 'Durazno'),
(5, 'Soriano'),
(6, 'Lavalleja'),
(7, 'San Jose'),
(8, 'Treinta y Tres'),
(9, 'Flores'),
(10, 'Colonia'),
(11, 'Rio Negro'),
(12, 'Tacuarembo'),
(13, 'Cerro Largo'),
(14, 'Paysandu'),
(15, 'Rivera'),
(16, 'Salto'),
(17, 'Artigas'),
(18, 'Maldonado'),
(19, 'Rocha');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `envios`
--

CREATE TABLE `envios` (
  `idPaquete` int(11) NOT NULL,
  `idLote` int(11) NOT NULL,
  `idAlmacenDestino` int(11) NOT NULL,
  `matricula` varchar(50) NOT NULL,
  `fechaEnvio` date NOT NULL,
  `fechaLlegada` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `envios`
--

INSERT INTO `envios` (`idPaquete`, `idLote`, `idAlmacenDestino`, `matricula`, `fechaEnvio`, `fechaLlegada`) VALUES
(1, 76, 2, 'STP6325', '2023-11-17', NULL),
(2, 76, 2, 'STP6325', '2023-11-17', NULL),
(4, 77, 4, 'STP6325', '2023-11-17', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lote`
--

CREATE TABLE `lote` (
  `id` int(11) NOT NULL,
  `camion` varchar(50) DEFAULT NULL,
  `idDepartamento` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `lote`
--

INSERT INTO `lote` (`id`, `camion`, `idDepartamento`) VALUES
(73, 'SELECT c.matricula\r\n            FROM camion c\r\n   ', 2),
(74, 'SELECT c.matricula\r\n                          FROM', 2),
(75, 'SELECT DISTINCT c.matricula\r\n              FROM ca', 2),
(76, 'STP6325', 2),
(77, 'STP6325', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paquete`
--

CREATE TABLE `paquete` (
  `id` int(11) NOT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `calle` varchar(50) NOT NULL,
  `nroPuerta` int(11) NOT NULL,
  `idDepartamento` int(11) NOT NULL,
  `fechaIngreso` datetime NOT NULL DEFAULT current_timestamp(),
  `estado` varchar(50) DEFAULT 'En Almacen',
  `idLote` int(11) DEFAULT NULL,
  `idAlmacenActual` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `paquete`
--

INSERT INTO `paquete` (`id`, `ciudad`, `calle`, `nroPuerta`, `idDepartamento`, `fechaIngreso`, `estado`, `idLote`, `idAlmacenActual`) VALUES
(1, 'Montevideo', 'Riveera', 2103, 2, '2023-11-17 00:39:11', 'Entregado', 76, 1),
(2, 'Colonia Del Sacramento', 'Av. Gonzalez Moreno', 3456, 2, '2023-11-17 00:39:11', 'Entregado', 76, 1),
(3, 'Punta Del Este', 'Gorlero', 6578, 3, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(4, 'Minas', 'Ellauri', 5467, 4, '2023-11-17 00:39:11', 'En Camino', 77, 1),
(5, 'La Paloma', 'Av.Navio', 7689, 5, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(6, 'Santa Clara de Olimar', 'Jose Reventos', 4564, 6, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(7, 'Punta Del Este', 'Av.del Mar', 6786, 7, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(8, 'La Paloma', 'Tamborcita', 6578, 8, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(9, 'San Jose', '25 de Mayo', 1231, 9, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(10, 'Montevideo', 'Aconcagua', 5227, 10, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(11, 'Colonia Del Sacramento', 'Aconcagua', 4351, 11, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(12, 'Montevideo', 'Francia', 5227, 12, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(13, 'Portones', 'Comercio', 1212, 13, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(14, 'Devoto', 'Comercio', 134131, 14, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(15, 'Barroso', 'Comercio', 123, 15, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(16, 'Francisco', 'Comercio', 4141, 16, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(17, 'Sarandi', 'Comercio', 141, 17, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(18, 'Gonzales', 'Comercio', 131, 18, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(19, 'Yi', '33 Comercio', 3131, 19, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(21, 'Montevideo', 'Comercio', 2103, 1, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(22, 'Montevideo', 'Comercio', 2103, 2, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(23, 'Montevideo', 'Comercio', 2103, 3, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(24, 'Montevideo', 'Comercio', 2103, 4, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(25, 'Montevideo', 'Comercio', 2103, 5, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(26, 'Montevideo', 'Comercio', 2103, 6, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(27, 'Montevideo', 'Comercio', 2103, 7, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(28, 'Montevideo', 'Comercio', 2103, 8, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(29, 'Montevideo', 'Comercio', 2103, 9, '2023-11-17 00:39:11', 'En Almacen', NULL, 1),
(30, 'Montevideo', 'Comamam', 2432, 10, '2023-11-17 00:39:11', 'En Almacen', NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `persona`
--

CREATE TABLE `persona` (
  `ci` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `tipo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `persona`
--

INSERT INTO `persona` (`ci`, `nombre`, `password`, `tipo`) VALUES
(32652155, 'Poroto', '1234', 'Camionero'),
(45956735, 'Tony', '1234', 'Camionero'),
(45987735, 'Rick', '1234', 'Camionero'),
(56749924, 'Facundo', '123', 'Administrador'),
(63436223, 'Paolo', '1234', 'Funcionario'),
(64254642, 'Franco', '1234', 'Camionero'),
(65434562, 'Morty', '1234', 'Funcionario'),
(65446235, 'Santiago', '1234', 'Administrador'),
(65452353, 'Hulk', '1234', 'Funcionario'),
(65455223, 'Federico', '1234', 'Administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ruta`
--

CREATE TABLE `ruta` (
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ruta`
--

INSERT INTO `ruta` (`id`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rutadepartamento`
--

CREATE TABLE `rutadepartamento` (
  `idRuta` int(11) NOT NULL,
  `idDepartamento` int(11) NOT NULL,
  `tiempo` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rutadepartamento`
--

INSERT INTO `rutadepartamento` (`idRuta`, `idDepartamento`, `tiempo`) VALUES
(5, 2, '00:56:00'),
(5, 3, '01:40:00'),
(5, 4, '02:42:00'),
(1, 5, '03:15:00'),
(8, 6, '03:25:00'),
(1, 7, '01:25:00'),
(8, 8, '03:55:00'),
(1, 9, '02:27:00'),
(1, 10, '02:25:00'),
(3, 11, '04:00:00'),
(5, 12, '05:00:00'),
(7, 13, '05:30:00'),
(3, 14, '04:50:00'),
(5, 15, '06:22:00'),
(3, 16, '06:12:00'),
(5, 17, '07:20:00'),
(9, 18, '02:00:00'),
(9, 19, '02:50:00');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `almacen`
--
ALTER TABLE `almacen`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idDepartamento` (`idDepartamento`);

--
-- Indices de la tabla `camion`
--
ALTER TABLE `camion`
  ADD PRIMARY KEY (`matricula`),
  ADD KEY `ciCamionero` (`ciCamionero`);

--
-- Indices de la tabla `camionrutas`
--
ALTER TABLE `camionrutas`
  ADD PRIMARY KEY (`matricula`,`idRuta`),
  ADD KEY `matricula` (`matricula`),
  ADD KEY `idRuta` (`idRuta`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `envios`
--
ALTER TABLE `envios`
  ADD PRIMARY KEY (`idPaquete`),
  ADD KEY `idAlmacenDestino` (`idAlmacenDestino`),
  ADD KEY `idLote` (`idLote`),
  ADD KEY `matricula` (`matricula`);

--
-- Indices de la tabla `lote`
--
ALTER TABLE `lote`
  ADD PRIMARY KEY (`id`),
  ADD KEY `camion` (`camion`),
  ADD KEY `idDepartamento` (`idDepartamento`);

--
-- Indices de la tabla `paquete`
--
ALTER TABLE `paquete`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idLote` (`idLote`),
  ADD KEY `idDepartamento` (`idDepartamento`),
  ADD KEY `almacen_ibfk_2` (`idAlmacenActual`);

--
-- Indices de la tabla `persona`
--
ALTER TABLE `persona`
  ADD PRIMARY KEY (`ci`);

--
-- Indices de la tabla `ruta`
--
ALTER TABLE `ruta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rutadepartamento`
--
ALTER TABLE `rutadepartamento`
  ADD PRIMARY KEY (`idDepartamento`),
  ADD KEY `idRuta` (`idRuta`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `almacen`
--
ALTER TABLE `almacen`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `lote`
--
ALTER TABLE `lote`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT de la tabla `paquete`
--
ALTER TABLE `paquete`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `almacen`
--
ALTER TABLE `almacen`
  ADD CONSTRAINT `almacen_ibfk_1` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`id`);

--
-- Filtros para la tabla `camion`
--
ALTER TABLE `camion`
  ADD CONSTRAINT `camion_ibfk_1` FOREIGN KEY (`ciCamionero`) REFERENCES `persona` (`ci`);

--
-- Filtros para la tabla `camionrutas`
--
ALTER TABLE `camionrutas`
  ADD CONSTRAINT `camionrutas_ibfk_1` FOREIGN KEY (`matricula`) REFERENCES `camion` (`matricula`),
  ADD CONSTRAINT `camionrutas_ibfk_2` FOREIGN KEY (`idRuta`) REFERENCES `ruta` (`id`);

--
-- Filtros para la tabla `envios`
--
ALTER TABLE `envios`
  ADD CONSTRAINT `envios_ibfk_4` FOREIGN KEY (`idPaquete`) REFERENCES `paquete` (`id`),
  ADD CONSTRAINT `envios_ibfk_5` FOREIGN KEY (`idAlmacenDestino`) REFERENCES `almacen` (`id`),
  ADD CONSTRAINT `envios_ibfk_6` FOREIGN KEY (`idLote`) REFERENCES `paquete` (`idLote`);

--
-- Filtros para la tabla `lote`
--
ALTER TABLE `lote`
  ADD CONSTRAINT `lote_ibfk_3` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`id`);

--
-- Filtros para la tabla `paquete`
--
ALTER TABLE `paquete`
  ADD CONSTRAINT `almacen_ibfk_2` FOREIGN KEY (`idAlmacenActual`) REFERENCES `almacen` (`id`),
  ADD CONSTRAINT `paquete_ibfk_2` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`id`),
  ADD CONSTRAINT `paquete_ibfk_3` FOREIGN KEY (`idLote`) REFERENCES `lote` (`id`);

--
-- Filtros para la tabla `rutadepartamento`
--
ALTER TABLE `rutadepartamento`
  ADD CONSTRAINT `rutadepartamento_ibfk_1` FOREIGN KEY (`idRuta`) REFERENCES `ruta` (`id`),
  ADD CONSTRAINT `rutadepartamento_ibfk_2` FOREIGN KEY (`idDepartamento`) REFERENCES `departamento` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;



/*------Consultas Opcionales------*/

select * from paquete p join almacen a on p.idAlmacenActual=a.id where idAlmacenActual=2;



/*------Consultas Obligatorias------*/
/*MOSTRAR LOS PAQUETES ENTREGADOS EN EL MES DE MAYO DEL 2023 CON DESTINO
A LA CIUDAD DE MELO*/

select p.id,p.estado from paquete p join envios e on p.id=e.idPaquete where p.ciudad='Melo' and estado='Entregado' and e.fechaLlegada BETWEEN '2023-05-01 00:00:00' AND '2023-05-31 23:59:59';

/*MOSTRAR TODOS LOS ALMACENES Y LOS PAQUETES QUE FUERON ENTREGADOS EN
LOS MISMOS DURANTE EL 2023, ORDENARLOS ADEMAS DE LOS QUE RECIBIERON MAS
PAQUETES A LOS QUE RECIBIERON MENOS.*/

SELECT
  e.idAlmacenDestino AS idAlmacen,
  COUNT(e.idPaquete) AS cantidadPaquetes,
  GROUP_CONCAT(e.idPaquete ORDER BY e.idPaquete) AS idPaquetesEntregados
FROM
  envios e
WHERE
  e.fechaLlegada BETWEEN '2023-01-01 00:00:00' AND '2023-12-31 23:59:59'
GROUP BY
  e.idAlmacenDestino
ORDER BY
  e.idAlmacenDestino;

/*MOSTRAR TODOS LOS CAMIONES REGISTRADOS Y QUE TEREA SE ENCUENTRAN
REALIZANDO EN ESTE MOMENTO*/

select * from camion;

/*MOSTRAR TODOS LOS CAMIONES QUE VISITARON DURANTE EL MES DE JUNIO UN
ALMACEN DADO*/

SELECT c.*, e.idAlmacenDestino
FROM camion c
JOIN envios e ON c.matricula = e.matricula
WHERE  MONTH(e.fechaLlegada) = 6 and e.idAlmacenDestino=2;

/*MOSTRAR DESTINO, LOTE, ALMACEN DE DESTINO Y CAMIÓN QUE TRANSPORTA UN
PAQUETE DADO.*/
SELECT
  e.idAlmacenDestino,
  p.idLote,
  e.matricula
FROM
  envios e
JOIN
  paquete p ON e.idPaquete = p.id
JOIN
  lote l ON p.idLote = l.id
JOIN
  almacen a ON e.idAlmacenDestino = a.id
JOIN
  camion c ON e.matricula = c.matricula
WHERE
  p.id = 2;
  
/*MOSTRAR EL IDENTIFICADOR DEL PAQUETE, IDENTIFICADOR DE LOTE, MATRICULA DEL
CAMION QUE LO TRANSPORTA, ALMACEN DE DESTINO, DIRECCIÓN FINAL Y EL ESTADO
DEL ENVÍO, PARA LOS PAQUETES QUE SE RECIBIERON HACE MAS DE 3 DÍAS.*/
SELECT
  p.id AS idPaquete,
  l.id,
  c.matricula AS matriculaCamion,
  e.idAlmacenDestino,
  p.estado
FROM
  envios e
JOIN
  paquete p ON e.idPaquete = p.id
JOIN
  lote l ON p.idLote = l.id
JOIN
  camion c ON e.matricula = c.matricula
WHERE
  e.fechaLlegada <= DATE_SUB(CURDATE(), INTERVAL 3 DAY);

/*MOSTRAR TODOS LOS PAQUETES A LOS QUE AÚN NO SE LES HA ASIGNADO UN LOTE Y
LA FECHA EN LA QUE FUERON RECIBIDOS.*/
SELECT
  p.id AS idPaquete,
  p.fechaIngreso
FROM
  paquete p
LEFT JOIN
  lote l ON p.idLote = l.id
WHERE
  p.idLote IS NULL;
  
/*MOSTRAR MATRICULA DE LOS CAMIONES QUE SE ENCUENTRAN FUERA DE SERVICIO.*/
select * from camion 
where estado='Fuera de Servicio';

/*MOSTRAR TODOS LOS CAMIONES QUE NO TIENEN UN CONDUCTOR ASIGNADO Y SU
ESTADO OPERATIVO.*/
SELECT
  c.matricula AS matriculaCamion,
  c.estado
FROM
  camion c
LEFT JOIN
 persona p ON c.ciCamionero = p.ci
WHERE
  c.ciCamionero IS NULL;
  
/*MOSTRAR TODOS LOS ALMACENES QUE SE ENCUENTRAN EN UN RECORRIDO DADO*/
select a.id,a.calle,a.nroPuerta,a.ciudad,d.nombre from almacen a 
join rutaDepartamento r on a.idDepartamento=r.idDepartamento
join departamento d on a.idDepartamento=d.id
where r.idRuta=1;



/*------CONSTRAINT------*/

ALTER TABLE `camion`
  ADD CONSTRAINT ChkMatricula CHECK (char_length(matricula)=7
  and substring(matricula,1,1)  regexp '^[A-S]$'
  and substring(matricula,2,1)  regexp '^[T]$'
  and substring(matricula,3,1)  regexp '^[P]$'
  and substring(matricula,4,4)  regexp '^[0-9]{4}$'
  );
  
  
